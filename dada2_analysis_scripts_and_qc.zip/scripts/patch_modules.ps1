# ============================================================
#  patch_modules.ps1
#  Fixes two defects:
#    1. duplicate 'sample_id' column breaking ggplot merges in
#       modules 06 and 08
#    2. outputs_check.csv being overwritten on every separate
#       Rscript invocation
#
#  Idempotent: safe to run more than once.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File "D:\oral data\scripts\patch_modules.ps1"
# ============================================================

$ErrorActionPreference = "Stop"
$SCRIPTS = "D:\oral data\scripts"

function Backup-And-Read($path) {
    if (-not (Test-Path $path)) {
        Write-Host ("  SKIP (not found): " + (Split-Path $path -Leaf)) -ForegroundColor Yellow
        return $null
    }
    $bk = "$path.bak_$(Get-Date -Format yyyyMMdd_HHmmss)"
    Copy-Item $path $bk
    return [System.IO.File]::ReadAllText($path)
}

function Write-Utf8NoBom($path, $text) {
    [System.IO.File]::WriteAllText($path, $text,
        (New-Object System.Text.UTF8Encoding($false)))
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " PATCHING ANALYSIS MODULES" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# ------------------------------------------------------------
# FIX 1: drop the duplicate sample_id column after meta_of()
# ------------------------------------------------------------
Write-Host "`n[1] duplicate sample_id column" -ForegroundColor Cyan

$marker = 'md$sample_id <- NULL'
$pattern = '(?m)^([ \t]*)md\s*<-\s*meta_of\(ps\)[ \t]*$'

foreach ($f in @("06_diversity.R", "07_differential_abundance.R", "08_caries_stunting.R")) {
    $p = Join-Path $SCRIPTS $f
    $t = Backup-And-Read $p
    if ($null -eq $t) { continue }

    if ($t.Contains($marker)) {
        Write-Host ("  already patched : " + $f) -ForegroundColor Gray
        continue
    }

    $m = [regex]::Matches($t, $pattern)
    if ($m.Count -eq 0) {
        Write-Host ("  no match in     : " + $f) -ForegroundColor Yellow
        continue
    }

    $new = [regex]::Replace($t, $pattern, {
        param($mm)
        $ind = $mm.Groups[1].Value
        $mm.Value + "`r`n" + $ind +
        'md$sample_id <- NULL  # rownames carry the ID; a duplicate column breaks merges'
    })

    Write-Utf8NoBom $p $new
    Write-Host ("  patched ({0} site(s)) : {1}" -f $m.Count, $f) -ForegroundColor Green
}

# ------------------------------------------------------------
# FIX 2: per-module outputs_check file
# ------------------------------------------------------------
Write-Host "`n[2] outputs_check.csv overwrite" -ForegroundColor Cyan

$p = Join-Path $SCRIPTS "utils_log.R"
$t = Backup-And-Read $p
if ($null -ne $t) {
    $old = 'file.path(DIRS$logs, "outputs_check.csv")'
    $new = 'file.path(DIRS$logs, paste0("outputs_check_", .LOGENV$module, ".csv"))'

    if ($t.Contains($new)) {
        Write-Host "  already patched : utils_log.R" -ForegroundColor Gray
    } elseif ($t.Contains($old)) {
        $t = $t.Replace($old, $new)
        Write-Utf8NoBom $p $t
        Write-Host "  patched         : utils_log.R" -ForegroundColor Green
        Write-Host "  checks now land in logs\outputs_check_<module>.csv" -ForegroundColor Gray
    } else {
        Write-Host "  pattern not found in utils_log.R" -ForegroundColor Yellow
    }
}

# ------------------------------------------------------------
# Verify the R files still parse
# ------------------------------------------------------------
Write-Host "`n[3] syntax check" -ForegroundColor Cyan
foreach ($f in @("utils_log.R", "06_diversity.R",
                 "07_differential_abundance.R", "08_caries_stunting.R")) {
    $p = Join-Path $SCRIPTS $f
    if (-not (Test-Path $p)) { continue }
    $null = & Rscript -e "invisible(parse('$($p -replace '\\','/')'))" 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host ("  OK   " + $f) -ForegroundColor Green
    } else {
        Write-Host ("  FAIL " + $f + "  (restore from the .bak file)") -ForegroundColor Red
    }
}

Write-Host "`nDone. Rerun modules 06 and 08.`n" -ForegroundColor Cyan

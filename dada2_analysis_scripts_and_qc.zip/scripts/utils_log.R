## ============================================================
##  utils_log.R
##  Logging, live progress, output validation, checkpointing
##
##  Three things are written:
##    logs/pipeline_<timestamp>.log  full append-only history
##    logs/STATUS.txt                current state, overwritten
##    logs/outputs_check.csv         every expected output + status
## ============================================================

.LOGENV <- new.env(parent = emptyenv())

log_init <- function(module) {
  if (is.null(.LOGENV$file)) {
    stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
    .LOGENV$file <- file.path(DIRS$logs, paste0("pipeline_", stamp, ".log"))
    .LOGENV$start <- Sys.time()
    .LOGENV$checks <- data.frame()
  }
  .LOGENV$module <- module
  .LOGENV$mod_start <- Sys.time()
  log_msg("", strrep("=", 62))
  log_msg("", sprintf(" MODULE: %s", module))
  log_msg("", sprintf(" started %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S")))
  log_msg("", strrep("=", 62))
  status_write(sprintf("MODULE %s starting", module))
}

log_msg <- function(level = "INFO", ...) {
  txt <- paste0(...)
  ts  <- format(Sys.time(), "%H:%M:%S")
  line <- if (nzchar(level))
    sprintf("[%s] %-5s %s", ts, level, txt) else txt
  cat(line, "\n", sep = "")
  flush.console()
  if (!is.null(.LOGENV$file))
    cat(line, "\n", sep = "", file = .LOGENV$file, append = TRUE)
  invisible(NULL)
}

log_info  <- function(...) log_msg("INFO",  ...)
log_warn  <- function(...) log_msg("WARN",  ...)
log_err   <- function(...) log_msg("ERROR", ...)
log_ok    <- function(...) log_msg("OK",    ...)

log_step <- function(...) {
  log_msg("", "")
  log_msg("STEP", ...)
  log_msg("", strrep("-", 62))
  status_write(paste0(...))
}

## ------------------------------------------------------------
##  Live status file. Open logs/STATUS.txt to see where the
##  pipeline is right now.
## ------------------------------------------------------------
status_write <- function(step, i = NULL, n = NULL, item = NULL) {
  el <- as.numeric(difftime(Sys.time(), .LOGENV$start, units = "mins"))
  lines <- c(
    "================ PIPELINE STATUS ================",
    sprintf(" updated   : %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S")),
    sprintf(" module    : %s", .LOGENV$module),
    sprintf(" step      : %s", step),
    sprintf(" elapsed   : %.1f min (total run)", el)
  )
  if (!is.null(i) && !is.null(n)) {
    pct <- 100 * i / n
    bar_n <- round(pct / 2.5)
    bar <- paste0("[", strrep("#", bar_n), strrep(".", 40 - bar_n), "]")
    mel <- as.numeric(difftime(Sys.time(), .LOGENV$mod_start, units = "mins"))
    eta <- if (i > 0) mel / i * (n - i) else NA
    lines <- c(lines,
      sprintf(" progress  : %s %.1f%%", bar, pct),
      sprintf(" item      : %d of %d   (%d remaining)", i, n, n - i),
      if (!is.null(item)) sprintf(" current   : %s", item) else NULL,
      sprintf(" step ETA  : %s",
              if (is.na(eta)) "calculating" else sprintf("%.1f min", eta))
    )
  }
  lines <- c(lines, "================================================")
  writeLines(lines, file.path(DIRS$logs, "STATUS.txt"))
  invisible(NULL)
}

## ------------------------------------------------------------
##  Per-item progress. Call inside loops.
## ------------------------------------------------------------
progress <- function(i, n, item = "", step = "processing", every = 1) {
  if (i %% every == 0 || i == n || i == 1) {
    pct <- 100 * i / n
    mel <- as.numeric(difftime(Sys.time(), .LOGENV$mod_start, units = "mins"))
    eta <- if (i > 0) mel / i * (n - i) else NA
    log_msg("PROG", sprintf("%4d/%-4d (%5.1f%%) %-24s remaining %3d  ETA %s",
                            i, n, pct, substr(item, 1, 24), n - i,
                            if (is.na(eta)) "--" else sprintf("%.0f min", eta)))
    status_write(step, i, n, item)
  }
  invisible(NULL)
}

## ------------------------------------------------------------
##  Output validation. Every module registers what it produced.
## ------------------------------------------------------------
check_output <- function(path, desc, min_bytes = 1, fatal = TRUE) {
  ok  <- file.exists(path)
  sz  <- if (ok) file.size(path) else 0
  ok  <- ok && sz >= min_bytes
  .LOGENV$checks <- rbind(.LOGENV$checks, data.frame(
    module = .LOGENV$module, description = desc, path = path,
    exists = file.exists(path), size_bytes = sz,
    status = if (ok) "OK" else "FAIL",
    time = format(Sys.time(), "%Y-%m-%d %H:%M:%S"),
    stringsAsFactors = FALSE))
  write.csv(.LOGENV$checks,
            file.path(DIRS$logs, paste0("outputs_check_", .LOGENV$module, ".csv")), row.names = FALSE)
  if (ok) {
    log_ok(sprintf("%-42s %8.1f KB", desc, sz / 1024))
  } else {
    log_err(sprintf("%-42s MISSING or EMPTY", desc))
    log_err("  expected at: ", path)
    if (fatal) stop("Required output missing: ", desc, call. = FALSE)
  }
  invisible(ok)
}

check_object <- function(obj, desc, expect_rows = NULL, expect_cols = NULL) {
  ok <- !is.null(obj)
  info <- ""
  if (ok && !is.null(dim(obj))) {
    info <- sprintf("%d x %d", nrow(obj), ncol(obj))
    if (!is.null(expect_rows) && nrow(obj) != expect_rows) {
      log_warn(sprintf("%s: expected %d rows, got %d",
                       desc, expect_rows, nrow(obj)))
      ok <- FALSE
    }
    if (!is.null(expect_cols) && ncol(obj) != expect_cols) {
      log_warn(sprintf("%s: expected %d cols, got %d",
                       desc, expect_cols, ncol(obj)))
      ok <- FALSE
    }
  } else if (ok) {
    info <- sprintf("length %d", length(obj))
  }
  if (ok) log_ok(sprintf("%-42s %s", desc, info))
  else    log_err(sprintf("%-42s FAILED %s", desc, info))
  invisible(ok)
}

## ------------------------------------------------------------
##  Checkpointing. Enables RESUME.
## ------------------------------------------------------------
ckpt_path <- function(name) file.path(DIRS$cache, paste0(name, ".rds"))

ckpt_exists <- function(name) RESUME && file.exists(ckpt_path(name))

ckpt_save <- function(obj, name) {
  saveRDS(obj, ckpt_path(name))
  log_info(sprintf("checkpoint saved: %s (%.1f MB)", name,
                   file.size(ckpt_path(name)) / 1024^2))
  invisible(obj)
}

ckpt_load <- function(name) {
  log_info(sprintf("checkpoint reused: %s (delete it to force a rerun)", name))
  readRDS(ckpt_path(name))
}

## run a step with automatic caching
cached <- function(name, expr) {
  if (ckpt_exists(name)) return(ckpt_load(name))
  val <- force(expr)
  ckpt_save(val, name)
  val
}

log_module_end <- function() {
  mins <- as.numeric(difftime(Sys.time(), .LOGENV$mod_start, units = "mins"))
  log_msg("", "")
  log_msg("DONE", sprintf("module %s finished in %.1f min",
                          .LOGENV$module, mins))
  status_write(sprintf("MODULE %s COMPLETE", .LOGENV$module))
  invisible(NULL)
}

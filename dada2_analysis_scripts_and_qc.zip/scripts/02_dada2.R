## ============================================================
##  02_dada2.R   (CORRECTED v3)
##
##  Changes from v2:
##   1. ddF, ddR and the merge are checkpointed SEPARATELY per
##      lane. Previously a whole lane was one cache unit, so a
##      stall during merging threw away hours of denoising.
##   2. mergePairs now runs sample by sample with progress
##      logging, so the step is visible instead of silent.
##   3. Fewer stdout writes, which reduces exposure to console
##      QuickEdit freezes on Windows.
##
##  Retained from v2: read-length-aware truncLen, padded quality
##  profiles, fatal abort on catastrophic filtering.
## ============================================================

suppressPackageStartupMessages({
  library(dada2); library(ShortRead); library(ggplot2)
})

log_init("02_dada2")

wide <- ckpt_load("manifest_01")
n <- nrow(wide)
log_info(sprintf("samples: %d   lanes: %s", n,
                 paste(sort(unique(wide$lane)), collapse = ", ")))

## ------------------------------------------------------------
## 1. Measure actual read lengths
## ------------------------------------------------------------
log_step("Measuring read lengths")

lenstat <- cached("read_lengths", {
  pick <- head(wide$sample, 12)
  getlen <- function(paths) {
    v <- integer(0)
    for (p in paths) {
      fs <- FastqSampler(p, n = 20000)
      rd <- yield(fs); close(fs)
      if (length(rd) > 0) v <- c(v, width(sread(rd)))
    }
    v
  }
  list(F = getlen(wide$R1[wide$sample %in% pick]),
       R = getlen(wide$R2[wide$sample %in% pick]))
})

if (length(lenstat$F) == 0 || length(lenstat$R) == 0)
  stop("Could not read any sequences from the module 01 outputs.")

summarise_len <- function(v, lab) {
  q <- quantile(v, c(0, TRUNC_SAFETY_Q, 0.5, 1))
  log_info(sprintf("%s length: min %d  q%.0f%% %d  median %d  max %d",
                   lab, q[1], 100 * TRUNC_SAFETY_Q, q[2], q[3], q[4]))
  as.integer(q[2])
}
capF <- summarise_len(lenstat$F, "R1")
capR <- summarise_len(lenstat$R, "R2")
log_info(sprintf("truncLen capped at c(%d, %d) so >= %.0f%% of reads survive",
                 capF, capR, 100 * (1 - TRUNC_SAFETY_Q)))

required <- AMPLICON_LEN + MIN_OVERLAP
if (capF + capR < required) {
  log_err(sprintf("Max achievable truncLen sum is %d but merging needs %d",
                  capF + capR, required))
  log_err("Either AMPLICON_LEN is wrong for these primers, or these")
  log_err("reads cannot be merged and forward-only analysis is needed.")
  stop("Overlap constraint cannot be satisfied at any truncLen.")
}
log_ok(sprintf("overlap feasible: max sum %d >= required %d",
               capF + capR, required))

## ------------------------------------------------------------
## 2. Quality profiles and truncLen
## ------------------------------------------------------------
log_step("Quality profiling and truncLen selection")

qprof <- cached("quality_profiles", {
  pick <- head(wide$sample, 12)
  med <- function(paths, maxw) {
    acc <- NULL
    for (p in paths) {
      fs <- FastqSampler(p, n = 20000)
      rd <- yield(fs); close(fs)
      if (length(rd) == 0) next
      q <- as(quality(rd), "matrix")
      if (ncol(q) < maxw)
        q <- cbind(q, matrix(NA_real_, nrow(q), maxw - ncol(q)))
      q <- q[, seq_len(maxw), drop = FALSE]
      acc <- rbind(acc, apply(q, 2, median, na.rm = TRUE))
    }
    apply(acc, 2, median, na.rm = TRUE)
  }
  list(F = med(wide$R1[wide$sample %in% pick], max(lenstat$F)),
       R = med(wide$R2[wide$sample %in% pick], max(lenstat$R)))
})

pick_trunc <- function(medq, cutoff, floor_at, cap) {
  medq <- medq[seq_len(min(length(medq), cap))]
  ok <- which(!is.na(medq) & medq >= cutoff)
  if (length(ok) == 0) return(min(floor_at, cap))
  max(min(floor_at, cap), min(max(ok), cap))
}

chosen <- NULL; used_cut <- NA_real_
for (cut in c(QUAL_TARGET, QUAL_FALLBACK)) {
  tF <- pick_trunc(qprof$F, cut, TRUNC_MIN_F, capF)
  tR <- pick_trunc(qprof$R, cut, TRUNC_MIN_R, capR)
  log_info(sprintf("Q>=%d -> truncLen c(%d, %d)  sum %d  (need >= %d)",
                   cut, tF, tR, tF + tR, required))
  if (tF + tR >= required) { chosen <- c(tF, tR); used_cut <- cut; break }
}
if (is.null(chosen)) {
  chosen <- c(capF, capR)
  log_warn("No quality cutoff satisfied the overlap requirement.")
  log_warn(sprintf("Using length caps c(%d, %d) to preserve merging.",
                   capF, capR))
}

TRUNCLEN <- chosen
stopifnot(TRUNCLEN[1] <= capF, TRUNCLEN[2] <= capR)
log_ok(sprintf("truncLen = c(%d, %d)  [Q %s, overlap %d bp, caps %d/%d]",
               TRUNCLEN[1], TRUNCLEN[2],
               if (is.na(used_cut)) "none" else used_cut,
               TRUNCLEN[1] + TRUNCLEN[2] - AMPLICON_LEN, capF, capR))

png(file.path(DIRS$fig, "01_quality_profiles.png"), 1400, 600, res = 130)
par(mfrow = c(1, 2))
plot(qprof$F, type = "l", ylim = c(0, 42), xlab = "cycle",
     ylab = "median Phred", main = "Forward (R1)")
abline(h = c(30, 20), lty = 3); abline(v = TRUNCLEN[1], col = "red", lwd = 2)
abline(v = capF, col = "blue", lty = 2)
plot(qprof$R, type = "l", ylim = c(0, 42), xlab = "cycle",
     ylab = "median Phred", main = "Reverse (R2)")
abline(h = c(30, 20), lty = 3); abline(v = TRUNCLEN[2], col = "red", lwd = 2)
abline(v = capR, col = "blue", lty = 2)
dev.off()
check_output(file.path(DIRS$fig, "01_quality_profiles.png"),
             "quality profile figure")
saveRDS(list(truncLen = TRUNCLEN, cutoff = used_cut,
             caps = c(capF, capR), profile = qprof),
        file.path(DIRS$dada, "trunclen_decision.rds"))

## ------------------------------------------------------------
## 3. Filter and trim
## ------------------------------------------------------------
log_step("Filtering and trimming")

fF <- file.path(DIRS$filt, paste0(wide$sample, "_F_filt.fastq.gz"))
fR <- file.path(DIRS$filt, paste0(wide$sample, "_R_filt.fastq.gz"))
names(fF) <- names(fR) <- wide$sample

filt_out <- cached("filter_stats", {
  out <- matrix(NA_real_, nrow = n, ncol = 2,
                dimnames = list(wide$sample, c("reads.in", "reads.out")))
  for (i in seq_len(n)) {
    r <- filterAndTrim(wide$R1[i], fF[i], wide$R2[i], fR[i],
                       truncLen = TRUNCLEN, maxN = MAXN, maxEE = MAXEE,
                       truncQ = TRUNCQ, rm.phix = RM_PHIX,
                       compress = TRUE, multithread = FALSE, verbose = FALSE)
    out[i, ] <- as.numeric(r[1, ])
    progress(i, n, wide$sample[i], "filterAndTrim", every = 5)
  }
  out
})

pass <- 100 * filt_out[, "reads.out"] / filt_out[, "reads.in"]
mean_pass <- mean(pass, na.rm = TRUE)
log_info(sprintf("pass rate: mean %.1f%%  min %.1f%%  max %.1f%%",
                 mean_pass, min(pass, na.rm = TRUE), max(pass, na.rm = TRUE)))

write.csv(data.frame(sample = rownames(filt_out), filt_out,
                     pct_pass = round(pass, 1)),
          file.path(DIRS$qc, "filter_stats.csv"), row.names = FALSE)
check_output(file.path(DIRS$qc, "filter_stats.csv"), "filter statistics")

keep <- file.exists(fF) & file.exists(fR) & file.size(fF) > 500
if (sum(keep) == 0 || is.nan(mean_pass) || mean_pass < MIN_FILTER_PASS) {
  log_err("")
  log_err("FILTERING FAILED CATASTROPHICALLY.")
  log_err(sprintf("  samples with output : %d of %d", sum(keep), n))
  log_err(sprintf("  mean pass rate      : %.1f%%", mean_pass))
  log_err(sprintf("  truncLen c(%d, %d) vs length caps c(%d, %d)",
                  TRUNCLEN[1], TRUNCLEN[2], capF, capR))
  log_err("  filterAndTrim DISCARDS reads shorter than truncLen.")
  log_err("  Delete cache/read_lengths.rds, cache/quality_profiles.rds,")
  log_err("  cache/filter_stats.rds and empty 03_dada2/filtered/.")
  stop("filterAndTrim produced no usable output")
}
if (any(!keep)) {
  log_warn(sprintf("%d samples produced no filtered reads, dropped:",
                   sum(!keep)))
  log_warn("   ", paste(wide$sample[!keep], collapse = ", "))
}
wide <- wide[keep, ]; fF <- fF[keep]; fR <- fR[keep]
n <- nrow(wide)
log_ok(sprintf("%d samples continue to denoising", n))

## ------------------------------------------------------------
## 4. Error models, per lane
## ------------------------------------------------------------
log_step("Learning error models per lane")

lanes <- sort(unique(wide$lane))
if (length(lanes) == 0) stop("No lanes remain.")
log_info(sprintf("%d lane(s): %s", length(lanes), paste(lanes, collapse = ", ")))

errs <- list()
for (li in seq_along(lanes)) {
  L <- lanes[li]
  idx <- which(wide$lane == L)
  log_info(sprintf("lane %s : %d samples", L, length(idx)))
  status_write(sprintf("learnErrors lane %s", L), li, length(lanes), L)

  errs[[L]] <- list(
    F = cached(paste0("errF_", L),
               learnErrors(fF[idx], nbases = ERR_NBASES,
                           multithread = THREADS, randomize = TRUE,
                           verbose = FALSE)),
    R = cached(paste0("errR_", L),
               learnErrors(fR[idx], nbases = ERR_NBASES,
                           multithread = THREADS, randomize = TRUE,
                           verbose = FALSE)))

  pf <- file.path(DIRS$fig, sprintf("02_errors_%s.png", L))
  png(pf, 1400, 700, res = 120)
  print(plotErrors(errs[[L]]$F, nominalQ = TRUE) +
          ggtitle(sprintf("Forward error model, lane %s", L)))
  dev.off()
  check_output(pf, sprintf("error plot lane %s", L), fatal = FALSE)
}

## ------------------------------------------------------------
## 5. Denoise and merge, each step separately checkpointed
## ------------------------------------------------------------
log_step("Denoising and merging")
log_info(sprintf("pooling mode: %s", as.character(POOL)))
log_info("ddF, ddR and merging are cached separately per lane, so a")
log_info("failure in one does not discard the others.")

as_list <- function(x, nm) {
  if (!is.list(x) || inherits(x, "dada")) x <- list(x)
  names(x) <- nm
  x
}

seqtabs <- list()
for (L in lanes) {
  idx <- which(wide$lane == L)
  sn  <- wide$sample[idx]
  log_info(sprintf("--- lane %s : %d samples ---", L, length(idx)))

  ## ---- forward ----
  status_write(sprintf("dada() forward, lane %s (%d samples)", L, length(idx)))
  t0 <- Sys.time()
  ddF <- cached(paste0("ddF_", L),
                dada(fF[idx], err = errs[[L]]$F, pool = POOL,
                     multithread = THREADS, verbose = FALSE))
  ddF <- as_list(ddF, sn)
  log_info(sprintf("lane %s forward denoising: %.1f min", L,
                   as.numeric(difftime(Sys.time(), t0, units = "mins"))))

  ## ---- reverse ----
  status_write(sprintf("dada() reverse, lane %s (%d samples)", L, length(idx)))
  t1 <- Sys.time()
  ddR <- cached(paste0("ddR_", L),
                dada(fR[idx], err = errs[[L]]$R, pool = POOL,
                     multithread = THREADS, verbose = FALSE))
  ddR <- as_list(ddR, sn)
  log_info(sprintf("lane %s reverse denoising: %.1f min", L,
                   as.numeric(difftime(Sys.time(), t1, units = "mins"))))

  ## ---- merge, sample by sample so progress is visible ----
  mg <- cached(paste0("merged_", L), {
    out <- vector("list", length(idx))
    names(out) <- sn
    for (k in seq_along(idx)) {
      out[[k]] <- mergePairs(ddF[[k]], fF[idx[k]],
                             ddR[[k]], fR[idx[k]],
                             minOverlap = MERGE_MINOV, verbose = FALSE)
      progress(k, length(idx), sn[k], sprintf("mergePairs lane %s", L))
    }
    out
  })

  ## ---- sequence table ----
  seqtabs[[L]] <- cached(paste0("seqtab_", L), {
    st <- makeSequenceTable(mg)
    rownames(st) <- sn
    attr(st, "ddF")    <- sapply(ddF, function(x) sum(getUniques(x)))
    attr(st, "ddR")    <- sapply(ddR, function(x) sum(getUniques(x)))
    attr(st, "merged") <- sapply(mg,  function(x) sum(getUniques(x)))
    st
  })

  mr <- 100 * mean(attr(seqtabs[[L]], "merged") /
                   pmax(attr(seqtabs[[L]], "ddF"), 1))
  log_info(sprintf("lane %s merge rate: %.1f%%", L, mr))
  if (mr < 50) {
    log_warn("MERGE RATE BELOW 50%. truncLen likely left too little")
    log_warn("overlap. Lower MIN_OVERLAP to 15 in config.R, delete")
    log_warn(sprintf("cache/merged_%s.rds and cache/seqtab_%s.rds,", L, L))
    log_warn("then rerun module 02. Denoising will NOT be repeated.")
  }
}

seqtab <- if (length(seqtabs) == 1) seqtabs[[1]] else
  mergeSequenceTables(tables = seqtabs)
log_ok(sprintf("sequence table: %d samples x %d ASVs",
               nrow(seqtab), ncol(seqtab)))

## ------------------------------------------------------------
## 6. Chimeras and length filtering
## ------------------------------------------------------------
log_step("Chimera removal")

seqtab_nc <- cached("seqtab_nochim",
  removeBimeraDenovo(seqtab, method = CHIMERA_METHOD,
                     multithread = THREADS, verbose = FALSE))
log_info(sprintf("ASVs %d -> %d after chimera removal (%.1f%% of reads kept)",
                 ncol(seqtab), ncol(seqtab_nc),
                 100 * sum(seqtab_nc) / sum(seqtab)))

lens <- nchar(colnames(seqtab_nc))
tl <- sort(table(lens), decreasing = TRUE)
log_info("merged length distribution (top 8):")
for (i in seq_len(min(8, length(tl))))
  log_info(sprintf("   %s bp : %d ASVs", names(tl)[i], tl[i]))

keep_len <- lens >= 350 & lens <= 480
log_info(sprintf("length filter 350-480 keeps %d/%d ASVs (%.1f%% of reads)",
                 sum(keep_len), length(lens),
                 100 * sum(seqtab_nc[, keep_len]) / sum(seqtab_nc)))
if (sum(keep_len) == 0)
  stop("No ASVs in the expected V3-V4 length range. Check AMPLICON_LEN.")
seqtab_final <- seqtab_nc[, keep_len, drop = FALSE]

ckpt_save(seqtab_final, "seqtab_final")
saveRDS(seqtab_final, file.path(DIRS$dada, "seqtab_final.rds"))
check_output(file.path(DIRS$dada, "seqtab_final.rds"), "final sequence table")

## ------------------------------------------------------------
## 7. Read tracking
## ------------------------------------------------------------
log_step("Read tracking")

track <- data.frame(sample = rownames(seqtab_final), stringsAsFactors = FALSE)
track$raw      <- filt_out[track$sample, "reads.in"]
track$filtered <- filt_out[track$sample, "reads.out"]
dd_f <- unlist(lapply(seqtabs, function(s) attr(s, "ddF")))
mg_n <- unlist(lapply(seqtabs, function(s) attr(s, "merged")))
track$denoised <- dd_f[track$sample]
track$merged   <- mg_n[track$sample]
track$nonchim  <- rowSums(seqtab_nc)[track$sample]
track$final    <- rowSums(seqtab_final)[track$sample]
track$pct_retained <- round(100 * track$final / track$raw, 1)

write.csv(track, file.path(DIRS$qc, "read_tracking.csv"), row.names = FALSE)
check_output(file.path(DIRS$qc, "read_tracking.csv"), "read tracking table")

log_info(sprintf("median retention raw -> final: %.1f%%",
                 median(track$pct_retained, na.rm = TRUE)))
log_info(sprintf("median final depth: %.0f reads",
                 median(track$final, na.rm = TRUE)))
lowd <- track$sample[track$final < MIN_READS_SAMPLE]
if (length(lowd) > 0) {
  log_warn(sprintf("%d samples below %d reads (dropped at module 05):",
                   length(lowd), MIN_READS_SAMPLE))
  log_warn("   ", paste(lowd, collapse = ", "))
}

asv_seqs <- colnames(seqtab_final)
asv_ids  <- sprintf("ASV%04d", seq_along(asv_seqs))
writeLines(as.vector(rbind(paste0(">", asv_ids), asv_seqs)),
           file.path(DIRS$export, "ASVs.fasta"))
check_output(file.path(DIRS$export, "ASVs.fasta"), "ASV FASTA (for PICRUSt2)")

ckpt_save(list(seqs = asv_seqs, ids = asv_ids), "asv_ids")
ckpt_save(wide, "manifest_02")

log_module_end()

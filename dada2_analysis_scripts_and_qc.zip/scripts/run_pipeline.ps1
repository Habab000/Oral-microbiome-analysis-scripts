# ============================================================
#  run_pipeline.ps1
#  Launcher. Activates the oralmb conda environment so that
#  cutadapt is on PATH, then runs the R pipeline.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File "D:\oral data\scripts\run_pipeline.ps1"
#
#  Run only some modules:
#    ... run_pipeline.ps1 -Modules 03,04
#
#  Watch progress from a SECOND PowerShell window:
#    Get-Content "D:\oral data\logs\STATUS.txt" -Wait
# ============================================================

param(
    [string[]]$Modules = @(),
    [switch]$Fresh          # delete caches and start over
)

$ErrorActionPreference = "Stop"
$PROJ    = "D:\oral data"
$SCRIPTS = Join-Path $PROJ "scripts"
$LOGS    = Join-Path $PROJ "logs"

New-Item -ItemType Directory -Force -Path $LOGS | Out-Null

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ORAL MICROBIOME ASV PIPELINE" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# ---- activate conda ----
$condaHook = "$env:USERPROFILE\miniconda3\shell\condabin\conda-hook.ps1"
if (Test-Path $condaHook) {
    & $condaHook
    conda activate oralmb
    Write-Host "conda env : $env:CONDA_DEFAULT_ENV" -ForegroundColor Green
} else {
    Write-Host "conda hook not found, continuing without activation" -ForegroundColor Yellow
}

if (Get-Command cutadapt -ErrorAction SilentlyContinue) {
    Write-Host ("cutadapt  : " + (cutadapt --version)) -ForegroundColor Green
} else {
    Write-Host "cutadapt  : NOT FOUND (fine if primers are already removed)" -ForegroundColor Yellow
}

$rs = Get-Command Rscript -ErrorAction SilentlyContinue
if (-not $rs) { Write-Host "Rscript not on PATH." -ForegroundColor Red; exit 1 }
Write-Host ("Rscript   : " + $rs.Source) -ForegroundColor Green

# ---- optional clean start ----
if ($Fresh) {
    Write-Host "`n-Fresh given. This deletes all cached intermediates." -ForegroundColor Yellow
    $ans = Read-Host "Type YES to confirm"
    if ($ans -ceq "YES") {
        Remove-Item (Join-Path $PROJ "03_dada2\cache\*") -Force -ErrorAction SilentlyContinue
        Write-Host "cache cleared" -ForegroundColor Green
    } else {
        Write-Host "cancelled, keeping cache" -ForegroundColor Yellow
    }
}

# ---- run ----
Write-Host "`nStarting. Watch live progress in another window with:" -ForegroundColor Cyan
Write-Host "  Get-Content `"$LOGS\STATUS.txt`" -Wait" -ForegroundColor White
Write-Host ""

$start = Get-Date
$argsR = @("`"$SCRIPTS\run_all.R`"") + $Modules
& Rscript $argsR
$code = $LASTEXITCODE
$mins = ((Get-Date) - $start).TotalMinutes

Write-Host ""
if ($code -eq 0) {
    Write-Host ("PIPELINE COMPLETE in {0:N1} min ({1:N1} h)" -f $mins, ($mins/60)) -ForegroundColor Green
} else {
    Write-Host ("PIPELINE FAILED after {0:N1} min. See the log below." -f $mins) -ForegroundColor Red
}

$latest = Get-ChildItem $LOGS -Filter "pipeline_*.log" |
          Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($latest) { Write-Host ("log    : " + $latest.FullName) -ForegroundColor Cyan }
Write-Host ("checks : " + (Join-Path $LOGS "outputs_check.csv")) -ForegroundColor Cyan

$chk = Join-Path $LOGS "outputs_check.csv"
if (Test-Path $chk) {
    $c = Import-Csv $chk
    $bad = $c | Where-Object { $_.status -ne "OK" }
    Write-Host ("outputs OK   : " + ($c | Where-Object { $_.status -eq "OK" }).Count) -ForegroundColor Green
    if ($bad) {
        Write-Host ("outputs FAIL : " + $bad.Count) -ForegroundColor Red
        $bad | Select-Object module, description | Format-Table -AutoSize
    }
}

exit $code

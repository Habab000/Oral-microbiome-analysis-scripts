## ============================================================
##  06_diversity.R
##  Alpha and beta diversity, run for BOTH databases.
##
##  Design decisions baked in, from the real data:
##   - depth ratio is only 2.2x, so rarefying changes almost
##     nothing. Alpha is reported at even depth (conventional)
##     AND non-rarefied (sensitivity). Beta uses relative
##     abundance and CLR, never rarefied counts.
##   - every group test is reported twice: unadjusted, and
##     adjusted for age + caries + sex, because caries runs
##     opposite to the exposure in this cohort.
##   - DMFT is the only continuous host variable available,
##     so it is also modelled continuously.
##
##  Outputs: 06_analysis/diversity/*.csv, 07_figures/diversity/*
## ============================================================

suppressPackageStartupMessages({
  library(phyloseq); library(vegan); library(ggplot2)
})

log_init("06_diversity")
source(file.path(DIRS$scripts, "utils_theme.R"))

## ============================================================
##  CONFIG
## ============================================================
PRIMARY_DB  <- "homd"    # "homd" or "silva"; both are run either way
PERM_N      <- 9999
RAREFY_SEED <- 42
TOP_TAXA    <- 15
COVARS      <- c("age_months", "caries", "sex")

OUT <- file.path(DIRS$ana, "diversity")
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)

## optional: Faith's PD
HAS_PICANTE <- requireNamespace("picante", quietly = TRUE)
if (!HAS_PICANTE) {
  log_warn("picante is not installed, so Faith's PD will be skipped.")
  log_warn("  install.packages('picante')  then rerun module 06.")
}

## ============================================================
##  Helpers
## ============================================================

meta_of <- function(ps) as(sample_data(ps), "data.frame")

## build a model formula from covariates that actually vary
usable_covars <- function(md, covars) {
  keep <- character()
  for (v in covars) {
    if (!v %in% names(md)) next
    x <- md[[v]]
    if (all(is.na(x))) next
    if (length(unique(na.omit(x))) < 2) {
      log_info(sprintf("   covariate '%s' has no variation, dropped", v))
      next
    }
    if (!is.numeric(x)) {
      tb <- table(x)
      if (min(tb) < 3) {
        log_info(sprintf("   covariate '%s' has a level with n<3, dropped", v))
        next
      }
    }
    keep <- c(keep, v)
  }
  keep
}

## ============================================================
##  Per-database analysis
## ============================================================
run_diversity <- function(dbname) {

  log_step(sprintf("DIVERSITY: %s", toupper(dbname)))

  ps <- readRDS(file.path(DIRS$ps, sprintf("ps_%s.rds", dbname)))
  md <- meta_of(ps)
  md$sample_id <- NULL  # rownames carry the ID; a duplicate column breaks merges
  md$group  <- factor(md$group,  levels = c("Non-stunted", "Stunted"))
  md$caries <- factor(md$caries, levels = c("Caries-free", "Caries"))
  sample_data(ps) <- sample_data(md)

  log_info(sprintf("%d samples, %d taxa", nsamples(ps), ntaxa(ps)))
  log_info(sprintf("group sizes: %s",
           paste(sprintf("%s=%d", names(table(md$group)), table(md$group)),
                 collapse = "  ")))

  cov_use <- usable_covars(md, COVARS)
  log_info(sprintf("adjusted model covariates: %s",
                   paste(cov_use, collapse = " + ")))

  depths <- sample_sums(ps)
  rdepth <- min(depths)
  log_info(sprintf("depth: min %.0f  median %.0f  max %.0f  (ratio %.1fx)",
                   min(depths), median(depths), max(depths),
                   max(depths) / min(depths)))
  log_info(sprintf("rarefaction depth for alpha: %.0f", rdepth))

  ## ----------------------------------------------------------
  ## 1. RAREFACTION CURVES
  ## ----------------------------------------------------------
  log_info("--- rarefaction curves ---")
  status_write(sprintf("rarefaction curves (%s)", dbname))

  otu <- as(otu_table(ps), "matrix")
  if (taxa_are_rows(ps)) otu <- t(otu)

  step <- max(1000, floor(rdepth / 60))
  rc <- vegan::rarecurve(round(otu), step = step, tidy = TRUE)
  names(rc) <- c("Site", "Sample_size", "Species")
  rc$group <- md$group[match(rc$Site, rownames(md))]

  p_rare <- ggplot(rc, aes(Sample_size, Species,
                           group = Site, colour = group)) +
    geom_line(linewidth = 0.4, alpha = 0.75) +
    geom_vline(xintercept = rdepth, linetype = 2,
               colour = "#555555", linewidth = 0.4) +
    annotate("text", x = rdepth, y = max(rc$Species) * 0.06,
             label = sprintf(" rarefaction depth = %s",
                             format(rdepth, big.mark = ",")),
             hjust = 0, size = 3, colour = "#555555") +
    scale_colour_study("group") +
    scale_x_continuous(labels = function(x) format(x, big.mark = ",")) +
    labs(title = "Rarefaction curves",
         subtitle = sprintf("%s reference | curves plateau well before the sampling depth",
                            toupper(dbname)),
         x = "Sequencing depth (reads)", y = "Observed ASVs",
         colour = "Group") +
    theme_study()
  save_fig(p_rare, sprintf("06_01_rarefaction_%s", dbname), 8, 5.5,
           subdir = "diversity")

  ## ----------------------------------------------------------
  ## 2. ALPHA DIVERSITY
  ## ----------------------------------------------------------
  log_info("--- alpha diversity ---")
  status_write(sprintf("alpha diversity (%s)", dbname))

  set.seed(RAREFY_SEED)
  ps_rar <- rarefy_even_depth(ps, sample.size = rdepth,
                              rngseed = RAREFY_SEED,
                              replace = FALSE, verbose = FALSE)
  log_info(sprintf("rarefied object: %d samples, %d taxa",
                   nsamples(ps_rar), ntaxa(ps_rar)))

  alpha_of <- function(obj, tag) {
    a <- estimate_richness(obj, measures = c("Observed", "Chao1",
                                             "Shannon", "Simpson",
                                             "InvSimpson"))
    rownames(a) <- gsub("^X", "", rownames(a))
    rownames(a) <- gsub("\\.", "-", rownames(a))
    a$Pielou <- a$Shannon / log(a$Observed)
    if (HAS_PICANTE) {
      m <- as(otu_table(obj), "matrix")
      if (taxa_are_rows(obj)) m <- t(m)
      pd <- picante::pd(m, phy_tree(obj), include.root = FALSE)
      a$FaithPD <- pd[rownames(a), "PD"]
    }
    a$sample_id <- rownames(a)
    a$dataset <- tag
    a
  }

  al_r <- alpha_of(ps_rar, "rarefied")
  al_n <- alpha_of(ps,     "non-rarefied")
  alpha <- rbind(al_r, al_n)
  alpha <- merge(alpha, md, by.x = "sample_id", by.y = "row.names")

  measures <- intersect(c("Observed", "Chao1", "Shannon", "Simpson",
                          "Pielou", "FaithPD"), names(alpha))

  ## --- tests: unadjusted and adjusted ---
  alpha_tests <- data.frame()
  for (ds in unique(alpha$dataset)) {
    d <- alpha[alpha$dataset == ds, ]
    for (mm in measures) {
      y <- d[[mm]]
      if (all(is.na(y))) next

      w <- tryCatch(wilcox.test(y ~ d$group, exact = FALSE),
                    error = function(e) NULL)
      p_un <- if (is.null(w)) NA_real_ else w$p.value

      ## effect size: Cliff's delta, robust and reportable
      a1 <- y[d$group == "Non-stunted"]; a2 <- y[d$group == "Stunted"]
      cd <- mean(outer(a2, a1, ">")) - mean(outer(a2, a1, "<"))

      f <- as.formula(paste(mm, "~ group +", paste(cov_use, collapse = " + ")))
      fit <- tryCatch(lm(f, data = d), error = function(e) NULL)
      p_adj <- NA_real_; est <- NA_real_
      if (!is.null(fit)) {
        cf <- summary(fit)$coefficients
        rw <- grep("^groupStunted", rownames(cf))
        if (length(rw) == 1) {
          p_adj <- cf[rw, 4]; est <- cf[rw, 1]
        }
      }

      alpha_tests <- rbind(alpha_tests, data.frame(
        database = dbname, dataset = ds, measure = mm,
        mean_nonstunted = mean(a1, na.rm = TRUE),
        mean_stunted    = mean(a2, na.rm = TRUE),
        cliffs_delta = round(cd, 3),
        p_unadjusted = p_un,
        adj_estimate = est,
        p_adjusted = p_adj,
        stringsAsFactors = FALSE))
    }
  }
  alpha_tests$q_unadjusted <- p.adjust(alpha_tests$p_unadjusted, "BH")
  alpha_tests$q_adjusted   <- p.adjust(alpha_tests$p_adjusted,   "BH")

  write.csv(alpha, file.path(OUT, sprintf("alpha_values_%s.csv", dbname)),
            row.names = FALSE)
  write.csv(alpha_tests, file.path(OUT, sprintf("alpha_tests_%s.csv", dbname)),
            row.names = FALSE)
  check_output(file.path(OUT, sprintf("alpha_tests_%s.csv", dbname)),
               sprintf("alpha diversity tests (%s)", dbname))

  log_info("alpha results (rarefied):")
  ar <- alpha_tests[alpha_tests$dataset == "rarefied", ]
  for (i in seq_len(nrow(ar))) {
    log_info(sprintf("   %-9s NS %8.2f  S %8.2f  delta %+.2f  p_un %.4f  p_adj %.4f",
                     ar$measure[i], ar$mean_nonstunted[i], ar$mean_stunted[i],
                     ar$cliffs_delta[i], ar$p_unadjusted[i], ar$p_adjusted[i]))
  }

  ## --- figure: violin + box + jitter ---
  al_long <- alpha[alpha$dataset == "rarefied",
                   c("sample_id", "group", measures)]
  al_long <- reshape(al_long, direction = "long",
                     varying = measures, v.names = "value",
                     timevar = "measure", times = measures,
                     idvar = "sample_id")
  lab <- ar[, c("measure", "p_adjusted")]
  lab$label <- sprintf("adj. %s %s", sapply(lab$p_adjusted, fmt_p),
                       sapply(lab$p_adjusted, star))

  p_alpha <- ggplot(al_long, aes(group, value, fill = group)) +
    geom_violin(alpha = 0.35, colour = NA, width = 0.85, trim = FALSE) +
    geom_boxplot(width = 0.18, outlier.shape = NA, alpha = 0.9,
                 colour = "#2B2B2B", linewidth = 0.35) +
    geom_jitter(aes(colour = group), width = 0.10, size = 1.3,
                alpha = 0.7, show.legend = FALSE) +
    facet_wrap(~ measure, scales = "free_y", nrow = 2) +
    geom_text(data = lab, aes(x = 1.5, y = Inf, label = label),
              inherit.aes = FALSE, vjust = 1.6, size = 2.9,
              colour = "#4A4A4A") +
    scale_fill_study("group") + scale_colour_study("group") +
    labs(title = "Alpha diversity by nutritional status",
         subtitle = sprintf("%s reference | rarefied to %s reads | p adjusted for %s",
                            toupper(dbname), format(rdepth, big.mark = ","),
                            paste(cov_use, collapse = ", ")),
         x = NULL, y = "Value", fill = "Group") +
    theme_study() + theme(axis.text.x = element_blank())
  save_fig(p_alpha, sprintf("06_02_alpha_%s", dbname), 9, 6.5,
           subdir = "diversity")

  ## --- alpha vs DMFT, the only continuous host variable ---
  if ("dmft" %in% names(alpha)) {
    ad <- alpha[alpha$dataset == "rarefied", ]
    cor_tab <- data.frame()
    for (mm in measures) {
      ct <- suppressWarnings(cor.test(ad[[mm]], ad$dmft, method = "spearman"))
      cor_tab <- rbind(cor_tab, data.frame(
        database = dbname, measure = mm, variable = "DMFT",
        rho = unname(ct$estimate), p = ct$p.value,
        stringsAsFactors = FALSE))
      ## within-group, to separate the caries effect from the group effect
      for (g in levels(ad$group)) {
        s <- ad[ad$group == g, ]
        ctg <- suppressWarnings(cor.test(s[[mm]], s$dmft, method = "spearman"))
        cor_tab <- rbind(cor_tab, data.frame(
          database = dbname, measure = mm,
          variable = paste0("DMFT within ", g),
          rho = unname(ctg$estimate), p = ctg$p.value,
          stringsAsFactors = FALSE))
      }
    }
    cor_tab$q <- p.adjust(cor_tab$p, "BH")
    write.csv(cor_tab, file.path(OUT, sprintf("alpha_dmft_correlations_%s.csv",
                                              dbname)), row.names = FALSE)
    log_info("alpha vs DMFT (Spearman, all samples):")
    ov <- cor_tab[cor_tab$variable == "DMFT", ]
    for (i in seq_len(nrow(ov)))
      log_info(sprintf("   %-9s rho %+.3f  p %.4f", ov$measure[i],
                       ov$rho[i], ov$p[i]))

    adl <- ad[, c("sample_id", "group", "dmft", measures)]
    adl <- reshape(adl, direction = "long", varying = measures,
                   v.names = "value", timevar = "measure",
                   times = measures, idvar = "sample_id")
    p_dmft <- ggplot(adl, aes(dmft, value)) +
      geom_point(aes(colour = group), size = 1.6, alpha = 0.75) +
      geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                  colour = "#2B2B2B", fill = "#D8D8D8", linewidth = 0.5) +
      facet_wrap(~ measure, scales = "free_y", nrow = 2) +
      scale_colour_study("group") +
      labs(title = "Alpha diversity against caries burden",
           subtitle = sprintf("%s reference | DMFT is the only continuous host variable available",
                              toupper(dbname)),
           x = "DMFT score", y = "Value", colour = "Group") +
      theme_study()
    save_fig(p_dmft, sprintf("06_03_alpha_vs_dmft_%s", dbname), 9, 6.5,
             subdir = "diversity")
  }

  ## ----------------------------------------------------------
  ## 3. BETA DIVERSITY
  ## ----------------------------------------------------------
  log_info("--- beta diversity ---")
  status_write(sprintf("beta diversity (%s)", dbname))

  ps_rel <- transform_sample_counts(ps, function(x) x / sum(x))

  ## CLR for Aitchison
  m <- as(otu_table(ps), "matrix")
  if (taxa_are_rows(ps)) m <- t(m)
  m1 <- m + 1
  clr <- log(m1) - rowMeans(log(m1))

  dists <- list(
    "Bray-Curtis"        = phyloseq::distance(ps_rel, "bray"),
    "Jaccard"            = phyloseq::distance(ps_rel, "jaccard", binary = TRUE),
    "Weighted UniFrac"   = phyloseq::distance(ps_rel, "wunifrac"),
    "Unweighted UniFrac" = phyloseq::distance(ps_rel, "uunifrac"),
    "Aitchison"          = dist(clr)
  )

  permanova <- data.frame()
  disper    <- data.frame()
  ord_list  <- list()

  for (dn in names(dists)) {
    D <- dists[[dn]]
    mdd <- md[labels(D), , drop = FALSE]

    f <- as.formula(paste("D ~ group +", paste(cov_use, collapse = " + ")))

    ## by = "margin": each term adjusted for all others. This is the
    ## number to report for the group effect.
    am <- tryCatch(adonis2(f, data = mdd, permutations = PERM_N,
                           by = "margin"), error = function(e) NULL)
    ## sequential, for the variance-explained narrative
    at <- tryCatch(adonis2(f, data = mdd, permutations = PERM_N,
                           by = "terms"), error = function(e) NULL)

    if (!is.null(am)) {
      for (trm in setdiff(rownames(am), c("Residual", "Total"))) {
        permanova <- rbind(permanova, data.frame(
          database = dbname, distance = dn, term = trm, type = "margin",
          R2 = am[trm, "R2"], F = am[trm, "F"],
          p = am[trm, "Pr(>F)"], stringsAsFactors = FALSE))
      }
    }
    if (!is.null(at)) {
      for (trm in setdiff(rownames(at), c("Residual", "Total"))) {
        permanova <- rbind(permanova, data.frame(
          database = dbname, distance = dn, term = trm, type = "sequential",
          R2 = at[trm, "R2"], F = at[trm, "F"],
          p = at[trm, "Pr(>F)"], stringsAsFactors = FALSE))
      }
    }

    ## dispersion. Reported as a RESULT, not only as an assumption
    ## check: greater dispersion in one group is itself a finding.
    bd <- tryCatch(betadisper(D, mdd$group), error = function(e) NULL)
    if (!is.null(bd)) {
      pt <- permutest(bd, permutations = PERM_N)
      dm <- tapply(bd$distances, mdd$group, mean)
      disper <- rbind(disper, data.frame(
        database = dbname, distance = dn,
        mean_dist_nonstunted = dm[["Non-stunted"]],
        mean_dist_stunted    = dm[["Stunted"]],
        F = pt$tab[1, "F"], p = pt$tab[1, "Pr(>F)"],
        stringsAsFactors = FALSE))
    }

    ord_list[[dn]] <- ordinate(ps_rel, method = "PCoA", distance = D)
  }

  pm_grp <- permanova[permanova$term == "group" & permanova$type == "margin", ]
  pm_grp$q <- p.adjust(pm_grp$p, "BH")
  permanova <- merge(permanova,
                     pm_grp[, c("distance", "q")], by = "distance", all.x = TRUE)

  write.csv(permanova, file.path(OUT, sprintf("permanova_%s.csv", dbname)),
            row.names = FALSE)
  write.csv(disper, file.path(OUT, sprintf("betadisper_%s.csv", dbname)),
            row.names = FALSE)
  check_output(file.path(OUT, sprintf("permanova_%s.csv", dbname)),
               sprintf("PERMANOVA results (%s)", dbname))

  log_info("PERMANOVA, group effect adjusted (by = margin):")
  for (i in seq_len(nrow(pm_grp)))
    log_info(sprintf("   %-19s R2 %.4f  F %5.2f  p %.4f  q %.4f",
                     pm_grp$distance[i], pm_grp$R2[i], pm_grp$F[i],
                     pm_grp$p[i], pm_grp$q[i]))

  log_info("Beta dispersion (Non-stunted vs Stunted):")
  for (i in seq_len(nrow(disper)))
    log_info(sprintf("   %-19s %.3f vs %.3f  p %.4f",
                     disper$distance[i], disper$mean_dist_nonstunted[i],
                     disper$mean_dist_stunted[i], disper$p[i]))

  ## --- PCoA panels ---
  ord_df <- data.frame()
  ax_lab <- list()
  for (dn in names(ord_list)) {
    o  <- ord_list[[dn]]
    ev <- o$values$Relative_eig
    v  <- as.data.frame(o$vectors[, 1:2])
    names(v) <- c("Axis1", "Axis2")
    v$sample_id <- rownames(v)
    v$distance <- dn
    ord_df <- rbind(ord_df, merge(v, md, by.x = "sample_id",
                                  by.y = "row.names"))
    ax_lab[[dn]] <- sprintf("%s (%.1f%%, %.1f%%)", dn, 100 * ev[1], 100 * ev[2])
  }
  ann <- pm_grp
  ann$label <- sprintf("R2 = %.3f, %s %s", ann$R2,
                       sapply(ann$p, fmt_p), sapply(ann$p, star))

  p_pcoa <- ggplot(ord_df, aes(Axis1, Axis2, colour = group, fill = group)) +
    stat_ellipse(geom = "polygon", alpha = 0.12, level = 0.80,
                 linewidth = 0.35) +
    geom_point(size = 2.1, alpha = 0.85) +
    facet_wrap(~ distance, scales = "free", nrow = 2) +
    geom_text(data = ann, aes(x = -Inf, y = Inf, label = label),
              inherit.aes = FALSE, hjust = -0.08, vjust = 1.5,
              size = 2.8, colour = "#4A4A4A") +
    scale_colour_study("group") + scale_fill_study("group") +
    labs(title = "Community structure by nutritional status",
         subtitle = sprintf("%s reference | PCoA | PERMANOVA adjusted for %s | 80%% ellipses",
                            toupper(dbname), paste(cov_use, collapse = ", ")),
         x = "PCoA 1", y = "PCoA 2", colour = "Group", fill = "Group") +
    theme_study(grid = "none")
  save_fig(p_pcoa, sprintf("06_04_pcoa_%s", dbname), 10, 7,
           subdir = "diversity")

  ## --- PCoA of the primary distance, coloured by every covariate ---
  best <- if (PRIMARY_DB == dbname) "Aitchison" else "Bray-Curtis"
  bd_df <- ord_df[ord_df$distance == best, ]
  for (v in intersect(c("caries", "sex", "anemia", "diet", "age_f", "lane"),
                      names(bd_df))) {
    bd_df[[v]] <- as.factor(bd_df[[v]])
    pv <- ggplot(bd_df, aes(Axis1, Axis2, colour = .data[[v]])) +
      stat_ellipse(level = 0.80, linewidth = 0.35) +
      geom_point(size = 2.1, alpha = 0.85) +
      scale_colour_study(if (v == "age_f") "age" else v) +
      labs(title = sprintf("%s ordination coloured by %s", best, v),
           subtitle = sprintf("%s reference", toupper(dbname)),
           x = "PCoA 1", y = "PCoA 2", colour = v) +
      theme_study(grid = "none")
    save_fig(pv, sprintf("06_05_pcoa_%s_by_%s", dbname, v), 6.5, 5.5,
             subdir = "diversity")
  }

  ## ----------------------------------------------------------
  ## 4. COMPOSITION
  ## ----------------------------------------------------------
  log_info("--- composition ---")
  status_write(sprintf("composition (%s)", dbname))

  comp_plot <- function(rank, topn, tag) {
    if (!rank %in% rank_names(ps)) return(invisible(NULL))
    g <- tax_glom(ps_rel, taxrank = rank, NArm = FALSE)
    dfm <- psmelt(g)
    dfm$Taxon <- as.character(dfm[[rank]])
    dfm$Taxon[is.na(dfm$Taxon)] <- "Unassigned"

    top <- names(sort(tapply(dfm$Abundance, dfm$Taxon, mean),
                      decreasing = TRUE))[seq_len(min(topn,
                      length(unique(dfm$Taxon))))]
    dfm$Taxon <- ifelse(dfm$Taxon %in% top, dfm$Taxon, "Other")
    dfm$Taxon <- factor(dfm$Taxon, levels = c(top, "Other"))

    cols <- setNames(c(PAL$taxa[seq_along(top)], "#CED4DA"),
                     c(top, "Other"))

    ## per-sample stacked bars
    p1 <- ggplot(dfm, aes(reorder(Sample, Abundance * (Taxon == top[1])),
                          Abundance, fill = Taxon)) +
      geom_col(width = 1) +
      facet_grid(~ group, scales = "free_x", space = "free_x") +
      scale_fill_manual(values = cols) +
      scale_y_continuous(labels = scales::percent_format(accuracy = 1),
                         expand = c(0, 0)) +
      labs(title = sprintf("%s-level composition", rank),
           subtitle = sprintf("%s reference | top %d %s", toupper(dbname),
                              length(top), tolower(rank)),
           x = "Sample", y = "Relative abundance", fill = rank) +
      theme_study(grid = "none") +
      theme(axis.text.x = element_blank(),
            axis.ticks.x = element_blank())
    save_fig(p1, sprintf("06_06_composition_%s_%s", tolower(rank), dbname),
             11, 6, subdir = "diversity")

    ## group means
    agg <- aggregate(Abundance ~ Taxon + group, dfm, mean)
    p2 <- ggplot(agg, aes(group, Abundance, fill = Taxon)) +
      geom_col(width = 0.65) +
      scale_fill_manual(values = cols) +
      scale_y_continuous(labels = scales::percent_format(accuracy = 1),
                         expand = c(0, 0)) +
      labs(title = sprintf("Mean %s-level composition by group", rank),
           subtitle = sprintf("%s reference", toupper(dbname)),
           x = NULL, y = "Mean relative abundance", fill = rank) +
      theme_study()
    save_fig(p2, sprintf("06_07_composition_mean_%s_%s", tolower(rank), dbname),
             7, 6, subdir = "diversity")

    write.csv(agg, file.path(OUT, sprintf("composition_%s_%s.csv",
                                          tolower(rank), dbname)),
              row.names = FALSE)
  }

  comp_plot("Phylum", 10, "phylum")
  comp_plot("Genus", TOP_TAXA, "genus")

  invisible(list(alpha = alpha_tests, permanova = permanova,
                 disper = disper))
}

## ============================================================
##  Run both databases
## ============================================================
res <- list()
for (dbn in c("silva", "homd")) {
  f <- file.path(DIRS$ps, sprintf("ps_%s.rds", dbn))
  if (!file.exists(f)) {
    log_warn(sprintf("%s object not found, skipped", dbn))
    next
  }
  res[[dbn]] <- run_diversity(dbn)
}

## ------------------------------------------------------------
##  Cross-database summary: does the conclusion depend on the
##  reference database? That is a reviewer question.
## ------------------------------------------------------------
if (length(res) == 2) {
  log_step("Cross-database agreement")

  pm <- do.call(rbind, lapply(res, function(x) x$permanova))
  pm <- pm[pm$term == "group" & pm$type == "margin", ]
  wide_pm <- reshape(pm[, c("database", "distance", "R2", "p")],
                     idvar = "distance", timevar = "database",
                     direction = "wide")
  write.csv(wide_pm, file.path(OUT, "permanova_db_comparison.csv"),
            row.names = FALSE)
  log_info("group effect, SILVA vs HOMD:")
  print(wide_pm, row.names = FALSE)

  same <- sign(wide_pm$p.silva < 0.05) == sign(wide_pm$p.homd < 0.05)
  if (all(same)) {
    log_ok("both references give the same significance verdict on every distance")
  } else {
    log_warn("the two references disagree on at least one distance.")
    log_warn("Report the primary database and show the other in supplementary.")
  }
}

log_info("")
log_info(sprintf("primary database for the manuscript: %s", toupper(PRIMARY_DB)))
log_info(sprintf("tables : %s", OUT))
log_info(sprintf("figures: %s", file.path(DIRS$fig, "diversity")))

log_module_end()

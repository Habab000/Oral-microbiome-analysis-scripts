# ============================================================
#  fix_group_rule.ps1
#  Sets KMUS013_RULE in 00c_metadata_prep.R, reruns that
#  script, and verifies the result is 27 vs 27.
#
#  Usage:
#    powershell -ExecutionPolicy Bypass -File "D:\oral data\scripts\fix_group_rule.ps1"
#
#  To use a different rule:
#    ... fix_group_rule.ps1 -Rule exclude
# ============================================================

param(
    [ValidateSet("stunted", "non_stunted", "exclude")]
    [string]$Rule = "stunted"
)

$ErrorActionPreference = "Stop"

$PROJ    = "D:\oral data"
$SCRIPTS = Join-Path $PROJ "scripts"
$TARGET  = Join-Path $SCRIPTS "00c_metadata_prep.R"
$OUTCSV  = Join-Path $PROJ "metadata\sample_data_clean.csv"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " SET KMUS013_RULE = $Rule" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# ---- 1. locate the script ----
if (-not (Test-Path $TARGET)) {
    Write-Host "Not found: $TARGET" -ForegroundColor Red
    exit 1
}
Write-Host "target : $TARGET" -ForegroundColor Gray

# ---- 2. back it up ----
$backup = "$TARGET.bak_$(Get-Date -Format yyyyMMdd_HHmmss)"
Copy-Item $TARGET $backup
Write-Host "backup : $backup" -ForegroundColor Gray

# ---- 3. show the current value ----
$text = [System.IO.File]::ReadAllText($TARGET)
$pattern = '(?m)^\s*KMUS013_RULE\s*<-\s*"[^"]*"'

$current = [regex]::Match($text, $pattern)
if (-not $current.Success) {
    Write-Host "`nCould not find a KMUS013_RULE assignment in the file." -ForegroundColor Red
    Write-Host "Expected a line like:  KMUS013_RULE <- `"exclude`"" -ForegroundColor Yellow
    Write-Host "Nothing was changed. Backup removed." -ForegroundColor Yellow
    Remove-Item $backup -Force
    exit 1
}
Write-Host ("before : " + $current.Value.Trim()) -ForegroundColor Yellow

# ---- 4. replace ----
$replacement = "KMUS013_RULE <- `"$Rule`""
$new = [regex]::Replace($text, $pattern, $replacement)

# UTF8 without BOM, or Rscript chokes on the byte order mark
[System.IO.File]::WriteAllText($TARGET, $new, (New-Object System.Text.UTF8Encoding($false)))

$check = [regex]::Match([System.IO.File]::ReadAllText($TARGET), $pattern)
if (-not $check.Success -or $check.Value.Trim() -ne $replacement) {
    Write-Host "Edit did not take. Restoring backup." -ForegroundColor Red
    Copy-Item $backup $TARGET -Force
    exit 1
}
Write-Host ("after  : " + $check.Value.Trim()) -ForegroundColor Green

# ---- 5. rerun the metadata prep ----
Write-Host "`nRunning 00c_metadata_prep.R ..." -ForegroundColor Cyan
Write-Host ""

$rs = Get-Command Rscript -ErrorAction SilentlyContinue
if (-not $rs) {
    Write-Host "Rscript not on PATH." -ForegroundColor Red
    exit 1
}

& Rscript $TARGET
if ($LASTEXITCODE -ne 0) {
    Write-Host "`n00c_metadata_prep.R failed. The edit is still in place;" -ForegroundColor Red
    Write-Host "restore with: Copy-Item `"$backup`" `"$TARGET`" -Force" -ForegroundColor Yellow
    exit 1
}

# ---- 6. verify the output ----
Write-Host "`n=== VERIFICATION ===" -ForegroundColor Cyan

if (-not (Test-Path $OUTCSV)) {
    Write-Host "sample_data_clean.csv was not written." -ForegroundColor Red
    exit 1
}

$rows = Import-Csv $OUTCSV
Write-Host ("rows in sample_data_clean.csv : " + $rows.Count)

if ($rows[0].PSObject.Properties.Name -contains "group") {
    Write-Host "`ngroup sizes:"
    $rows | Group-Object group | Sort-Object Name | ForEach-Object {
        Write-Host ("  {0,-14} {1}" -f $_.Name, $_.Count)
    }
}
if ($rows[0].PSObject.Properties.Name -contains "cohort_code") {
    Write-Host "`ncohort codes:"
    $rows | Group-Object cohort_code | Sort-Object Name | ForEach-Object {
        Write-Host ("  {0,-14} {1}" -f $_.Name, $_.Count)
    }
}

# is KMUS-013 present and labelled as intended?
$k13 = $rows | Where-Object { $_.sample_id -eq "KMUS-013" }
Write-Host ""
if ($Rule -eq "exclude") {
    if ($k13) {
        Write-Host "KMUS-013 : STILL PRESENT (expected it to be dropped)" -ForegroundColor Red
    } else {
        Write-Host "KMUS-013 : correctly excluded" -ForegroundColor Green
    }
} else {
    if ($k13) {
        Write-Host ("KMUS-013 : present, group = " + $k13.group) -ForegroundColor Green
    } else {
        Write-Host "KMUS-013 : MISSING (expected it to be kept)" -ForegroundColor Red
    }
}

Write-Host ""
if ($Rule -eq "stunted" -and $rows.Count -eq 54) {
    Write-Host "RESULT: 54 samples. Ready to run the pipeline." -ForegroundColor Green
} elseif ($Rule -eq "exclude" -and $rows.Count -eq 53) {
    Write-Host "RESULT: 53 samples, as expected for the exclude rule." -ForegroundColor Green
} else {
    Write-Host ("RESULT: " + $rows.Count + " samples. Check the Table 1 report:") -ForegroundColor Yellow
    Write-Host ("  " + (Join-Path $PROJ "01_qc\table1_descriptives.txt")) -ForegroundColor Yellow
}

Write-Host "`nbackup kept at: $backup" -ForegroundColor Gray

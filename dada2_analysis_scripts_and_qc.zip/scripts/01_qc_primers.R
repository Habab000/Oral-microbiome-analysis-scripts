## ============================================================
##  01_qc_primers.R   (CORRECTED)
##  Fix: the cutadapt retention parser now works, so the
##  "abort if retention is catastrophic" safety net actually
##  functions instead of silently producing NaN.
## ============================================================

suppressPackageStartupMessages({
  library(ShortRead); library(Biostrings)
})

log_init("01_qc_primers")

## ------------------------------------------------------------
## 1. Index raw files
## ------------------------------------------------------------
log_step("Indexing raw FASTQ files")

fq <- list.files(DIRS$raw, pattern = "\\.(fq|fastq)\\.gz$", full.names = TRUE)
if (length(fq) == 0) stop("No FASTQ files in ", DIRS$raw)
bn <- basename(fq)

man <- data.frame(
  path   = fq,
  file   = bn,
  sample = sub("^(KMU[A-Z]*-[0-9]+).*$", "\\1", bn),
  lane   = ifelse(grepl("_L[0-9]+_", bn),
                  sub("^.*_(L[0-9]+)_.*$", "\\1", bn), "L1"),
  read   = sub("^.*_([12])\\.(fq|fastq)\\.gz$", "\\1", bn),
  stringsAsFactors = FALSE
)
man$cohort <- sub("-[0-9]+$", "", man$sample)
man$sample <- vapply(man$sample, function(x) {
  p <- regmatches(x, regexec("^(KMU[A-Z]*)-0*([0-9]+)$", x))[[1]]
  if (length(p) == 3) sprintf("%s-%03d", p[2], as.integer(p[3])) else x
}, character(1))
man <- man[man$cohort %in% PROCESS_COHORTS, ]

wide <- reshape(man[, c("sample", "cohort", "lane", "read", "path")],
                idvar = c("sample", "cohort", "lane"),
                timevar = "read", direction = "wide")
names(wide)[names(wide) == "path.1"] <- "R1_raw"
names(wide)[names(wide) == "path.2"] <- "R2_raw"
wide <- wide[order(wide$sample), ]
rownames(wide) <- NULL

log_info(sprintf("samples indexed : %d", nrow(wide)))
for (k in names(table(wide$cohort)))
  log_info(sprintf("   cohort %-8s %d", k, table(wide$cohort)[[k]]))
for (k in names(table(wide$lane)))
  log_info(sprintf("   lane   %-8s %d", k, table(wide$lane)[[k]]))

if (any(is.na(wide$R1_raw)) || any(is.na(wide$R2_raw)))
  stop("Some samples are missing a mate. Check 00_raw.")
log_ok("every sample has both mates")

## lane confounding
sd_p <- file.path(DIRS$meta, "sample_data_clean.csv")
if (file.exists(sd_p)) {
  sd <- read.csv(sd_p, stringsAsFactors = FALSE)
  j  <- merge(sd, wide[, c("sample", "lane")],
              by.x = "sample_id", by.y = "sample")
  if (length(unique(j$lane)) > 1) {
    tb <- table(j$lane, j$group)
    p  <- tryCatch(fisher.test(tb)$p.value, error = function(e) NA_real_)
    log_info("lane x group in the analysis set:")
    for (r in rownames(tb)) {
      log_info(sprintf("   %-4s %s", r,
               paste(sprintf("%s=%d", colnames(tb), tb[r, ]), collapse = "  ")))
    }
    if (!is.na(p) && p < 0.10) {
      log_warn(sprintf("lane is associated with group (p=%.3f).", p))
      log_warn("Batch is partly confounded. Record as a limitation.")
    } else {
      log_ok("lane is not confounded with group")
    }
  }
}

## ------------------------------------------------------------
## 2. Primer detection
## ------------------------------------------------------------
log_step("Detecting primers")

detect <- cached("primer_detection", {
  probe <- unlist(lapply(split(wide, paste(wide$lane, wide$cohort)),
                         function(x) head(x$sample, 3)))
  probe <- unique(probe)
  log_info(sprintf("probing %d samples", length(probe)))

  grab <- function(p, n = 20000) {
    fs <- FastqStreamer(p, n = n); on.exit(close(fs))
    rd <- yield(fs)
    if (length(rd) == 0) return(NULL)
    narrow(sread(rd), 1, pmin(width(sread(rd)), 40))
  }
  hit <- function(w, pr) {
    if (is.null(w)) return(NA_real_)
    100 * mean(vcountPattern(DNAString(pr), w, fixed = FALSE,
                             max.mismatch = PRIMER_MM) > 0)
  }

  out <- data.frame()
  for (i in seq_along(probe)) {
    s <- probe[i]
    r <- wide[wide$sample == s, ][1, ]
    w1 <- tryCatch(grab(r$R1_raw), error = function(e) NULL)
    w2 <- tryCatch(grab(r$R2_raw), error = function(e) NULL)
    out <- rbind(out, data.frame(
      sample = s, lane = r$lane,
      R1_FWD = hit(w1, FWD_PRIMER), R1_REV = hit(w1, REV_PRIMER),
      R2_FWD = hit(w2, FWD_PRIMER), R2_REV = hit(w2, REV_PRIMER)))
    progress(i, length(probe), s, "primer detection")
  }
  out
})

write.csv(detect, file.path(DIRS$qc, "primer_detection.csv"), row.names = FALSE)
check_output(file.path(DIRS$qc, "primer_detection.csv"), "primer detection table")

m_fwd <- mean(detect$R1_FWD, na.rm = TRUE)
m_rev <- mean(detect$R2_REV, na.rm = TRUE)
m_mix <- mean(c(detect$R1_REV, detect$R2_FWD), na.rm = TRUE)
log_info(sprintf("341F in R1 : %.1f%%", m_fwd))
log_info(sprintf("805R in R2 : %.1f%%", m_rev))
log_info(sprintf("cross-orientation signal : %.1f%%", m_mix))

## ------------------------------------------------------------
## 3. Decision
## ------------------------------------------------------------
log_step("Primer decision")

decision <- list(mixed = FALSE)
if (!is.na(m_mix) && m_mix > 25) {
  log_warn("Substantial cross-orientation signal. Reads may be in")
  log_warn("MIXED ORIENTATION, which splits each organism in two.")
  decision$mixed <- TRUE
}

score <- max(m_fwd, m_rev, na.rm = TRUE)
if (score >= PRIMER_HI) {
  decision$action <- "trim"
  log_info("VERDICT: primers present -> running cutadapt")
} else if (score <= PRIMER_LO) {
  decision$action <- "skip"
  log_info("VERDICT: primers already removed -> skipping cutadapt")
} else {
  decision$action <- "trim_lenient"
  log_warn(sprintf("VERDICT: ambiguous (%.1f%%). Lenient cutadapt:", score))
  log_warn("primers removed where found, reads without one are KEPT.")
}

## ------------------------------------------------------------
## 4. Trim
## ------------------------------------------------------------
if (decision$action == "skip") {
  wide$R1 <- wide$R1_raw
  wide$R2 <- wide$R2_raw
  log_info("input for DADA2 = raw files")
} else {
  log_step("Running cutadapt")

  if (!nzchar(Sys.which("cutadapt")))
    stop("cutadapt not on PATH. Launch via run_pipeline.ps1, which ",
         "activates the oralmb conda environment.")
  log_info("cutadapt: ", system2("cutadapt", "--version", stdout = TRUE)[1])
  log_info(sprintf("341F is %d nt and 805R is %d nt, so trimmed reads will",
                   nchar(FWD_PRIMER), nchar(REV_PRIMER)))
  log_info(sprintf("be about %d bp (R1) and %d bp (R2). Module 02 measures",
                   READ_LEN - nchar(FWD_PRIMER), READ_LEN - nchar(REV_PRIMER)))
  log_info("the real lengths and caps truncLen below them.")

  logdir <- file.path(DIRS$trim, "logs")
  dir.create(logdir, showWarnings = FALSE, recursive = TRUE)
  discard <- if (decision$action == "trim") "--discard-untrimmed" else NULL

  ## robust parser for cutadapt's summary block
  parse_keep <- function(lines) {
    ln <- grep("Pairs written \\(passing filters\\)|Reads written \\(passing filters\\)",
               lines, value = TRUE)
    if (length(ln) == 0) return(NA_real_)
    m <- regmatches(ln[1], regexpr("\\(([0-9.]+)%\\)", ln[1]))
    if (length(m) == 0) return(NA_real_)
    as.numeric(gsub("[()%]", "", m))
  }
  parse_n <- function(lines, label) {
    ln <- grep(label, lines, value = TRUE)
    if (length(ln) == 0) return(NA_real_)
    v <- regmatches(ln[1], regexpr("[0-9,]+", sub(".*:", "", ln[1])))
    if (length(v) == 0) return(NA_real_)
    as.numeric(gsub(",", "", v))
  }

  summ <- data.frame()
  for (i in seq_len(nrow(wide))) {
    s  <- wide$sample[i]
    o1 <- file.path(DIRS$trim, paste0(s, "_R1.fastq.gz"))
    o2 <- file.path(DIRS$trim, paste0(s, "_R2.fastq.gz"))
    lg <- file.path(logdir, paste0(s, ".log"))

    if (!(RESUME && file.exists(o1) && file.exists(o2) &&
          file.size(o1) > 1000 && file.exists(lg))) {
      args <- c("-g", paste0("^", FWD_PRIMER),
                "-G", paste0("^", REV_PRIMER),
                discard,
                "-e", CUTADAPT_E, "-m", CUTADAPT_MIN, "-j", 1,
                "-o", shQuote(o1), "-p", shQuote(o2),
                shQuote(wide$R1_raw[i]), shQuote(wide$R2_raw[i]))
      rc <- system2("cutadapt", args, stdout = lg, stderr = lg)
      if (rc != 0) {
        log_err("cutadapt failed for ", s, ", see ", lg)
        stop("cutadapt failure on ", s)
      }
    }

    lines <- readLines(lg, warn = FALSE)
    summ <- rbind(summ, data.frame(
      sample   = s,
      in_pairs = parse_n(lines, "Total read pairs processed"),
      out_pairs= parse_n(lines, "passing filters"),
      pct_kept = parse_keep(lines),
      stringsAsFactors = FALSE))
    progress(i, nrow(wide), s, "cutadapt")
  }

  write.csv(summ, file.path(DIRS$trim, "cutadapt_summary.csv"),
            row.names = FALSE)
  check_output(file.path(DIRS$trim, "cutadapt_summary.csv"), "cutadapt summary")

  nparsed <- sum(!is.na(summ$pct_kept))
  if (nparsed == 0) {
    log_err("Could not parse retention from ANY cutadapt log.")
    log_err("The safety net is blind, so the run stops here rather than")
    log_err("continuing without knowing whether trimming worked.")
    log_err("Inspect: ", file.path(logdir, paste0(wide$sample[1], ".log")))
    stop("cutadapt log parsing failed")
  }

  mk <- mean(summ$pct_kept, na.rm = TRUE)
  log_info(sprintf("mean retention: %.1f%%  (parsed %d/%d logs)",
                   mk, nparsed, nrow(summ)))
  low <- summ$sample[!is.na(summ$pct_kept) & summ$pct_kept < 70]
  if (length(low) > 0) {
    log_warn(sprintf("%d samples below 70%% retention:", length(low)))
    log_warn("   ", paste(head(low, 15), collapse = ", "))
  }
  if (mk < MIN_CUTADAPT_KEEP) {
    log_err(sprintf("Mean retention %.1f%% is below the %d%% floor.",
                    mk, MIN_CUTADAPT_KEEP))
    log_err("Stopping rather than building an ASV table from scraps.")
    stop("cutadapt retention too low")
  }

  wide$R1 <- file.path(DIRS$trim, paste0(wide$sample, "_R1.fastq.gz"))
  wide$R2 <- file.path(DIRS$trim, paste0(wide$sample, "_R2.fastq.gz"))
}

## ------------------------------------------------------------
## 5. Hand off
## ------------------------------------------------------------
missing <- wide$sample[!file.exists(wide$R1) | !file.exists(wide$R2)]
if (length(missing) > 0)
  stop("Missing inputs after module 01: ", paste(missing, collapse = ", "))
log_ok(sprintf("all %d samples have usable inputs", nrow(wide)))

attr(wide, "primer_decision") <- decision
ckpt_save(wide, "manifest_01")
write.csv(wide[, c("sample", "cohort", "lane", "R1", "R2")],
          file.path(DIRS$qc, "manifest_after_trimming.csv"), row.names = FALSE)
check_output(file.path(DIRS$qc, "manifest_after_trimming.csv"),
             "manifest for module 02")

log_module_end()

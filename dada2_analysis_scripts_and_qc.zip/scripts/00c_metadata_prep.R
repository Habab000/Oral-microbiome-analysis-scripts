## ============================================================
##  00c_metadata_prep.R
##  Phase 0c : build the clean analysis metadata table
##
##  Does   : reads the metadata workbook, defines groups from the
##           Nutritional status column, recodes and collapses
##           covariates, applies the KMUS-013 decision rule,
##           restricts to the analysis set, and produces a
##           Table 1 descriptive summary with tests
##
##  Writes : metadata/sample_data_clean.csv
##           01_qc/table1_descriptives.txt
##
##  Run with:
##    Rscript "D:/oral data/scripts/00c_metadata_prep.R"
## ============================================================

suppressPackageStartupMessages({
  library(readxl)
})

## ============================================================
##  CONFIG  -- the only lines you should ever need to change
## ============================================================

## How to handle KMUS-013, which is labelled Non-stunted despite
## the KMUS prefix. Options:
##   "exclude"     : drop it from the analysis  (RECOMMENDED default)
##   "non_stunted" : trust the Nutritional status column
##   "stunted"     : trust the code prefix
KMUS013_RULE <- "stunted"

## Cohorts to keep. KMUOB is excluded on the professor's instruction.
KEEP_COHORTS <- c("KMUN", "KMUS")

## ============================================================

PROJ <- "D:/oral data"
META <- file.path(PROJ, "metadata")
QC   <- file.path(PROJ, "01_qc")
dir.create(QC, showWarnings = FALSE, recursive = TRUE)

report <- file.path(QC, "table1_descriptives.txt")
sink(report, split = TRUE)

cat("============================================================\n")
cat(" METADATA PREPARATION AND TABLE 1\n")
cat(" ", format(Sys.time()), "\n")
cat(" KMUS-013 rule:", KMUS013_RULE, "\n")
cat("============================================================\n\n")

## ------------------------------------------------------------
## 1. Locate and read the workbook
## ------------------------------------------------------------
xl <- list.files(META, pattern = "\\.(xlsm|xlsx|xls)$",
                 full.names = TRUE, ignore.case = TRUE)
if (length(xl) == 0) { sink(); stop("No Excel file found in ", META) }
target <- xl[1]
cat("Reading:", basename(target), "\n")

read_any <- function(path, sheet) {
  tryCatch(
    suppressMessages(read_excel(path, sheet = sheet, .name_repair = "minimal")),
    error = function(e)
      suppressMessages(read_excel(path, sheet = sheet, guess_max = 2000))
  )
}

sheets <- excel_sheets(target)
md <- NULL
for (s in sheets) {
  tmp <- try(read_any(target, s), silent = TRUE)
  if (inherits(tmp, "try-error")) next
  if (any(grepl("^code$", trimws(tolower(names(tmp)))))) { md <- tmp; break }
}
if (is.null(md)) {
  sink()
  stop("No sheet with a 'Code' column. If this is an .xlsm that readxl ",
       "cannot open, re-save it as .xlsx and rerun.")
}
md <- as.data.frame(md, check.names = FALSE)
names(md) <- trimws(names(md))
cat("Rows read:", nrow(md), " Columns:", ncol(md), "\n\n")

## ------------------------------------------------------------
## 2. Locate columns by pattern (names are long and messy)
## ------------------------------------------------------------
pick <- function(pattern, required = TRUE) {
  hit <- names(md)[grepl(pattern, names(md), ignore.case = TRUE)]
  if (length(hit) == 0) {
    if (required) { sink(); stop("Column not found for pattern: ", pattern) }
    return(NA_character_)
  }
  hit[1]
}

c_code  <- pick("^code$")
c_age   <- pick("agemon")
c_sex   <- pick("^sex$")
c_brush <- pick("brush",       required = FALSE)
c_diet  <- pick("dietary",     required = FALSE)
c_nut   <- pick("nutritional")
c_anem  <- pick("anemic",      required = FALSE)
c_dmft  <- pick("dmft score")
c_carp  <- pick("caries presence")
c_cars  <- pick("caries severity", required = FALSE)

## ------------------------------------------------------------
## 3. Build the clean table
## ------------------------------------------------------------
norm_id <- function(x) {
  x <- toupper(gsub("[_ ]", "-", trimws(as.character(x))))
  m <- regmatches(x, regexec("^(KMU[A-Z]*)-?0*([0-9]+)$", x))
  vapply(m, function(p)
    if (length(p) == 3) sprintf("%s-%03d", p[2], as.integer(p[3]))
    else NA_character_, character(1))
}

d <- data.frame(
  sample_id = norm_id(md[[c_code]]),
  stringsAsFactors = FALSE
)
d$cohort_code <- sub("-[0-9]+$", "", d$sample_id)

## group from the CLINICAL column, not the prefix
nut <- trimws(as.character(md[[c_nut]]))
d$group <- ifelse(grepl("^non", nut, ignore.case = TRUE), "Non-stunted",
           ifelse(grepl("stunt", nut, ignore.case = TRUE), "Stunted", NA))

## covariates
d$age_months <- suppressWarnings(as.numeric(md[[c_age]]))
d$sex        <- ifelse(toupper(trimws(as.character(md[[c_sex]]))) == "M",
                       "Male", "Female")
d$dmft       <- suppressWarnings(as.numeric(md[[c_dmft]]))
d$caries     <- ifelse(grepl("^y", trimws(as.character(md[[c_carp]])),
                             ignore.case = TRUE), "Caries", "Caries-free")

if (!is.na(c_cars)) {
  sev <- trimws(as.character(md[[c_cars]]))
  d$caries_severity <- ifelse(grepl("free",     sev, ignore.case = TRUE), "None",
                       ifelse(grepl("mild",     sev, ignore.case = TRUE), "Mild",
                       ifelse(grepl("moderate|severe", sev, ignore.case = TRUE),
                              "Moderate-severe", NA)))
}
if (!is.na(c_anem)) {
  d$anemia <- ifelse(grepl("^non", trimws(as.character(md[[c_anem]])),
                           ignore.case = TRUE), "Non-anemic", "Anemic")
}
if (!is.na(c_brush)) {
  d$brushing <- ifelse(grepl("^y", trimws(as.character(md[[c_brush]])),
                             ignore.case = TRUE), "Yes", "No")
}

## diet: collapse the singleton Plant-Based level
if (!is.na(c_diet)) {
  dp <- trimws(as.character(md[[c_diet]]))
  d$diet_raw <- dp
  d$diet <- ifelse(grepl("staple",  dp, ignore.case = TRUE), "Staple-dominant",
            ifelse(grepl("diverse|mixed|plant", dp, ignore.case = TRUE),
                   "Diverse/mixed", NA))
}

## ------------------------------------------------------------
## 4. Apply exclusions
## ------------------------------------------------------------
cat("--- EXCLUSIONS ---\n")
n0 <- nrow(d)
cat(sprintf("  all samples in workbook          : %d\n", n0))

d <- d[d$cohort_code %in% KEEP_COHORTS, , drop = FALSE]
cat(sprintf("  after dropping KMUOB             : %d\n", nrow(d)))

## the label conflict
conflict <- d$sample_id[
  (d$cohort_code == "KMUS" & d$group != "Stunted") |
  (d$cohort_code == "KMUN" & d$group != "Non-stunted")]
conflict <- conflict[!is.na(conflict)]

if (length(conflict)) {
  cat(sprintf("  prefix/label conflicts           : %s\n",
              paste(conflict, collapse = ", ")))
  if (KMUS013_RULE == "exclude") {
    d <- d[!d$sample_id %in% conflict, , drop = FALSE]
    cat("  rule 'exclude' applied           : dropped\n")
  } else if (KMUS013_RULE == "stunted") {
    d$group[d$sample_id %in% conflict] <- "Stunted"
    cat("  rule 'stunted' applied           : reassigned to Stunted\n")
  } else {
    cat("  rule 'non_stunted' applied       : kept as labelled\n")
  }
} else {
  cat("  prefix/label conflicts           : none\n")
}

d <- d[!is.na(d$group), , drop = FALSE]
cat(sprintf("  FINAL ANALYSIS SET               : %d\n\n", nrow(d)))

## factor levels: Non-stunted is the reference
d$group  <- factor(d$group, levels = c("Non-stunted", "Stunted"))
d$caries <- factor(d$caries, levels = c("Caries-free", "Caries"))
d$sex    <- factor(d$sex,    levels = c("Female", "Male"))
d$age_f  <- factor(d$age_months, levels = sort(unique(d$age_months)),
                   ordered = TRUE)
if (!is.null(d$anemia))
  d$anemia <- factor(d$anemia, levels = c("Non-anemic", "Anemic"))
if (!is.null(d$diet))
  d$diet <- factor(d$diet, levels = c("Diverse/mixed", "Staple-dominant"))

## ------------------------------------------------------------
## 5. Table 1
## ------------------------------------------------------------
cat("--- TABLE 1: ANALYSIS SET BY GROUP ---\n\n")
cat(sprintf("  %-28s %-18s %-18s %s\n",
            "Variable", levels(d$group)[1], levels(d$group)[2], "p"))
cat("  ", strrep("-", 78), "\n", sep = "")

n1 <- sum(d$group == "Non-stunted"); n2 <- sum(d$group == "Stunted")
cat(sprintf("  %-28s %-18s %-18s\n", "n", n1, n2))

cat_row <- function(var, label) {
  v <- d[[var]]
  if (is.null(v)) return(invisible())
  tb <- table(v, d$group)
  p  <- tryCatch(fisher.test(tb, simulate.p.value = nrow(tb) > 2)$p.value,
                 error = function(e) NA_real_)
  cat(sprintf("  %-28s %-18s %-18s %s\n", label, "", "",
              if (is.na(p)) "" else sprintf("%.3f", p)))
  for (lv in rownames(tb)) {
    cat(sprintf("    %-26s %-18s %-18s\n",
                lv,
                sprintf("%d (%.0f%%)", tb[lv, 1], 100 * tb[lv, 1] / n1),
                sprintf("%d (%.0f%%)", tb[lv, 2], 100 * tb[lv, 2] / n2)))
  }
}

num_row <- function(var, label) {
  v <- d[[var]]
  if (is.null(v)) return(invisible())
  a <- v[d$group == "Non-stunted"]; b <- v[d$group == "Stunted"]
  p <- tryCatch(wilcox.test(a, b, exact = FALSE)$p.value,
                error = function(e) NA_real_)
  cat(sprintf("  %-28s %-18s %-18s %s\n", label,
              sprintf("%.2f (%.2f)", mean(a), sd(a)),
              sprintf("%.2f (%.2f)", mean(b), sd(b)),
              if (is.na(p)) "" else sprintf("%.3f", p)))
  cat(sprintf("    %-26s %-18s %-18s\n", "median [IQR]",
              sprintf("%.1f [%.1f-%.1f]", median(a), quantile(a, .25), quantile(a, .75)),
              sprintf("%.1f [%.1f-%.1f]", median(b), quantile(b, .25), quantile(b, .75))))
}

num_row("age_months", "Age, months, mean (SD)")
cat_row("age_f",  "Age category")
cat_row("sex",    "Sex")
cat_row("caries", "Caries status")
num_row("dmft",   "DMFT score, mean (SD)")
if (!is.null(d$caries_severity)) cat_row("caries_severity", "Caries severity")
if (!is.null(d$anemia))          cat_row("anemia",          "Anemia")
if (!is.null(d$diet))            cat_row("diet",            "Dietary pattern")
if (!is.null(d$brushing))        cat_row("brushing",        "Tooth brushing")

cat("\n  Categorical: Fisher exact. Continuous: Wilcoxon rank sum.\n")
cat("  These are descriptive. Do not use them to select covariates.\n\n")

## ------------------------------------------------------------
## 6. Confounding warnings
## ------------------------------------------------------------
cat("--- CONFOUNDING CHECK ---\n")

pcar <- tryCatch(fisher.test(table(d$caries, d$group))$p.value,
                 error = function(e) NA)
if (!is.na(pcar) && pcar < 0.10) {
  cat("  ** CARIES is imbalanced across groups.\n")
  cat("     Caries is a dominant driver of oral microbiome composition.\n")
  cat("     Adjust for it in every model and run a caries-free\n")
  cat("     sensitivity analysis (n =", sum(d$caries == "Caries-free"), ").\n")
}

page <- tryCatch(wilcox.test(age_months ~ group, data = d,
                             exact = FALSE)$p.value, error = function(e) NA)
if (!is.na(page) && page < 0.10) {
  cat("  ** AGE is imbalanced across groups. Include as a covariate.\n")
}

for (v in c("brushing", "diet", "anemia")) {
  if (is.null(d[[v]])) next
  tb <- table(d[[v]], d$group)
  mn <- min(rowSums(tb))
  if (mn < 5) cat(sprintf("  ** %s has a sparse level (n = %d). ", v, mn),
                  "Collapse or drop it.\n", sep = "")
}
cat("\n")

## ------------------------------------------------------------
## 7. Write out
## ------------------------------------------------------------
d$age_f <- as.character(d$age_f)
out <- file.path(META, "sample_data_clean.csv")
write.csv(d, out, row.names = FALSE)

cat("--- OUTPUT ---\n")
cat("  written :", out, "\n")
cat("  columns :", paste(names(d), collapse = ", "), "\n\n")

cat("  Proposed primary model:\n")
cat("    ~ group + age_months + caries + sex\n\n")
cat("  Sensitivity analyses to run later:\n")
cat("    (a) caries-free subset only\n")
cat("    (b) KMUS013_RULE flipped to 'non_stunted'\n")
cat("    (c) anemia added, to test over-adjustment\n\n")

cat("============================================================\n")
cat(" DONE. Report saved to:\n ", report, "\n")
cat("============================================================\n")

sink()

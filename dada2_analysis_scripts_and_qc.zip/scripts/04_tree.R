## ============================================================
##  04_tree.R
##  Neighbour-joining phylogeny for UniFrac and Faith's PD.
##  No maximum-likelihood refinement: it costs hours and does
##  not change UniFrac results enough to matter here.
## ============================================================

suppressPackageStartupMessages({
  library(DECIPHER); library(phangorn); library(Biostrings)
})

log_init("04_tree")

seqtab <- ckpt_load("seqtab_final")
ids    <- ckpt_load("asv_ids")
seqs   <- colnames(seqtab)
log_info(sprintf("ASVs to align: %d", length(seqs)))

if (length(seqs) > 8000) {
  log_warn(sprintf("%d ASVs is a large alignment. Expect the alignment",
                   length(seqs)))
  log_warn("step to take a long time and use several GB of RAM.")
}

## ------------------------------------------------------------
## 1. Align
## ------------------------------------------------------------
log_step("Aligning ASV sequences")
status_write("DECIPHER AlignSeqs")

aln <- cached("alignment", {
  t0 <- Sys.time()
  dna <- DNAStringSet(seqs); names(dna) <- ids$ids
  a <- AlignSeqs(dna, anchor = NA, processors = THREADS, verbose = FALSE)
  log_info(sprintf("alignment took %.1f min",
                   as.numeric(difftime(Sys.time(), t0, units = "mins"))))
  a
})
check_object(aln, "multiple sequence alignment")
log_info(sprintf("alignment width: %d columns", width(aln)[1]))

writeXStringSet(aln, file.path(DIRS$export, "ASVs_aligned.fasta"))
check_output(file.path(DIRS$export, "ASVs_aligned.fasta"),
             "aligned ASV FASTA", fatal = FALSE)

## ------------------------------------------------------------
## 2. Distance and NJ tree
## ------------------------------------------------------------
log_step("Building neighbour-joining tree")

tree <- cached("tree_nj", {
  status_write("converting alignment to phyDat")
  pd <- phyDat(as(aln, "matrix"), type = "DNA")

  status_write("computing ML distance matrix")
  t0 <- Sys.time()
  dm <- dist.ml(pd)
  log_info(sprintf("distance matrix took %.1f min",
                   as.numeric(difftime(Sys.time(), t0, units = "mins"))))

  status_write("neighbour joining")
  t1 <- Sys.time()
  tr <- NJ(dm)
  log_info(sprintf("NJ took %.1f min",
                   as.numeric(difftime(Sys.time(), t1, units = "mins"))))
  tr
})

check_object(tree, "NJ tree")
log_info(sprintf("tree tips: %d", length(tree$tip.label)))

if (length(tree$tip.label) != length(seqs))
  log_warn("Tree tip count does not match ASV count. UniFrac will ",
           "silently subset. Investigate before trusting beta diversity.")

## negative branch lengths are a known NJ artefact and break UniFrac
neg <- sum(tree$edge.length < 0, na.rm = TRUE)
if (neg > 0) {
  log_warn(sprintf("%d negative branch lengths from NJ. Setting them to 0,",
                   neg))
  log_warn("which is the standard fix and is required for UniFrac.")
  tree$edge.length[tree$edge.length < 0] <- 0
}

## midpoint rooting: UniFrac needs a rooted tree
tree_rooted <- tryCatch(phangorn::midpoint(tree), error = function(e) {
  log_warn("midpoint rooting failed, rooting at the first tip instead")
  ape::root(tree, outgroup = tree$tip.label[1], resolve.root = TRUE)
})
log_ok("tree rooted")

ckpt_save(tree_rooted, "tree")
saveRDS(tree_rooted, file.path(DIRS$ps, "tree_nj.rds"))
ape::write.tree(tree_rooted, file.path(DIRS$export, "ASVs_tree.nwk"))
check_output(file.path(DIRS$ps, "tree_nj.rds"), "rooted NJ tree")
check_output(file.path(DIRS$export, "ASVs_tree.nwk"), "Newick tree")

log_module_end()

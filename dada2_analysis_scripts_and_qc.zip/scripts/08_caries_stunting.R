## ============================================================
##  08_caries_stunting.R
##
##  The paper's contribution. In this cohort caries runs OPPOSITE
##  to stunting (non-stunted children have roughly 2.5x the DMFT),
##  which is the reverse of what most readers assume and differs
##  from published cohorts at the same age. So caries is treated
##  here as a CO-EXPOSURE rather than a nuisance covariate.
##
##  Questions answered:
##    1. Do stunting and caries move the community in the same
##       direction, different directions, or orthogonally?
##    2. Which taxa track stunting, which track caries, and which
##       track both (concordantly or discordantly)?
##    3. Does DMFT modelled continuously add anything over the
##       binary caries variable?
##    4. Is there a group x caries interaction?
##
##  Honest limits, logged at runtime: one of the four cells has
##  n = 7, so the interaction test has very little power. The
##  effect-size comparison in the quadrant figure carries more
##  weight than the interaction p value.
##
##  Outputs
##    06_analysis/caries_stunting/*.csv
##    07_figures/caries_stunting/*
## ============================================================

suppressPackageStartupMessages({
  library(phyloseq); library(vegan); library(ggplot2)
})

log_init("08_caries_stunting")
source(file.path(DIRS$scripts, "utils_theme.R"))

## ============================================================
##  CONFIG
## ============================================================
PRIMARY_DB   <- "homd"
PRIMARY_RANK <- "Genus"
PRV_CUT      <- 0.10
ALPHA        <- 0.05
PERM_N       <- 9999
BASE_COVARS  <- c("age_months", "sex")   # caries and group are the exposures
LABEL_N      <- 18                        # taxa labelled on the quadrant plot

OUT <- file.path(DIRS$ana, "caries_stunting")
FIG <- "caries_stunting"
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(DIRS$fig, FIG), showWarnings = FALSE, recursive = TRUE)

HAS_MAAS <- requireNamespace("Maaslin2", quietly = TRUE)
if (!HAS_MAAS) stop("Maaslin2 is required for module 08.")

## extra palette for the four-cell design
PAL$cell <- c(
  "Non-stunted / Caries-free" = "#8ECAE6",
  "Non-stunted / Caries"      = "#2A9D8F",
  "Stunted / Caries-free"     = "#F4A261",
  "Stunted / Caries"          = "#E76F51")

meta_of <- function(ps) as(sample_data(ps), "data.frame")

usable_covars <- function(md, covars) {
  keep <- character()
  for (v in covars) {
    if (!v %in% names(md)) next
    x <- md[[v]]
    if (all(is.na(x)) || length(unique(na.omit(x))) < 2) next
    if (!is.numeric(x) && min(table(x)) < 3) next
    keep <- c(keep, v)
  }
  keep
}

prep_rank <- function(ps, rank) {
  if (!rank %in% rank_names(ps)) return(NULL)
  g <- tax_glom(ps, taxrank = rank, NArm = TRUE)
  tn <- as.character(tax_table(g)[, rank])
  g <- prune_taxa(!is.na(tn) & tn != "", g)
  taxa_names(g) <- make.unique(as.character(tax_table(g)[, rank]))
  ot <- as(otu_table(g), "matrix")
  if (taxa_are_rows(g)) ot <- t(ot)
  prune_taxa(colSums(ot > 0) / nrow(ot) >= PRV_CUT, g)
}

maas_fit <- function(g, md, fixed, ref, tag) {
  ot <- as(otu_table(g), "matrix")
  if (taxa_are_rows(g)) ot <- t(ot)
  md2 <- md[rownames(ot), , drop = FALSE]
  tmp <- file.path(tempdir(), paste0("m8_", gsub("\\W", "_", tag)))
  tryCatch(
    Maaslin2::Maaslin2(input_data = as.data.frame(ot), input_metadata = md2,
                       output = tmp, fixed_effects = fixed, reference = ref,
                       normalization = "TSS", transform = "LOG",
                       analysis_method = "LM", min_prevalence = 0,
                       min_abundance = 0, max_significance = 1,
                       correction = "BH", plot_heatmap = FALSE,
                       plot_scatter = FALSE, standardize = FALSE)$results,
    error = function(e) { log_warn("Maaslin2 failed (", tag, "): ",
                                   conditionMessage(e)); NULL })
}

term_of <- function(rr, meta_name, value_name = NULL, prefix) {
  if (is.null(rr)) return(NULL)
  s <- rr[rr$metadata == meta_name, ]
  if (!is.null(value_name)) s <- s[s$value == value_name, ]
  if (nrow(s) == 0) return(NULL)
  d <- data.frame(taxon = s$feature, coef = s$coef, se = s$stderr,
                  p = s$pval, q = s$qval, stringsAsFactors = FALSE)
  names(d)[-1] <- paste0(prefix, "_", names(d)[-1])
  d
}

## ============================================================
##  Main
## ============================================================
for (dbname in c("silva", "homd")) {
  f <- file.path(DIRS$ps, sprintf("ps_%s.rds", dbname))
  if (!file.exists(f)) { log_warn(sprintf("%s missing, skipped", dbname)); next }

  log_step(sprintf("CARIES x STUNTING: %s", toupper(dbname)))

  ps <- readRDS(f)
  md <- meta_of(ps)
  md$sample_id <- NULL  # rownames carry the ID; a duplicate column breaks merges
  md$group  <- factor(md$group,  levels = c("Non-stunted", "Stunted"))
  md$caries <- factor(md$caries, levels = c("Caries-free", "Caries"))
  md$sex    <- factor(md$sex)
  md$cell   <- factor(paste(md$group, md$caries, sep = " / "),
                      levels = names(PAL$cell))
  sample_data(ps) <- sample_data(md)

  cov_use <- usable_covars(md, BASE_COVARS)

  ## ----------------------------------------------------------
  ## 1. The four-cell design
  ## ----------------------------------------------------------
  log_info("--- four-cell design ---")
  tb <- table(md$group, md$caries)
  for (r in rownames(tb))
    log_info(sprintf("   %-14s %s", r,
             paste(sprintf("%s=%d", colnames(tb), tb[r, ]), collapse = "  ")))
  small <- min(tb)
  log_warn(sprintf("   smallest cell n = %d. The group x caries interaction",
                   small))
  log_warn("   test is underpowered at this size. Read the effect-size")
  log_warn("   comparison (quadrant figure) rather than the interaction p.")

  ct <- data.frame(group = rep(rownames(tb), ncol(tb)),
                   caries = rep(colnames(tb), each = nrow(tb)),
                   n = as.vector(tb))
  write.csv(ct, file.path(OUT, sprintf("cell_sizes_%s.csv", dbname)),
            row.names = FALSE)

  ## association between the two exposures
  ft <- fisher.test(tb)
  log_info(sprintf("   caries vs stunting association: OR %.2f, p %.4f",
                   unname(ft$estimate), ft$p.value))
  dm <- tapply(md$dmft, md$group, mean)
  wt <- wilcox.test(dmft ~ group, data = md, exact = FALSE)
  log_info(sprintf("   mean DMFT: non-stunted %.2f vs stunted %.2f, p %.4f",
                   dm[["Non-stunted"]], dm[["Stunted"]], wt$p.value))

  ## ----------------------------------------------------------
  ## 2. Two-factor PERMANOVA with interaction
  ## ----------------------------------------------------------
  log_info("--- two-factor PERMANOVA ---")
  status_write(sprintf("two-factor PERMANOVA (%s)", dbname))

  ps_rel <- transform_sample_counts(ps, function(x) x / sum(x))
  m0 <- as(otu_table(ps), "matrix")
  if (taxa_are_rows(ps)) m0 <- t(m0)
  m1 <- m0 + 1
  clr <- log(m1) - rowMeans(log(m1))

  dists <- list("Bray-Curtis"      = phyloseq::distance(ps_rel, "bray"),
                "Weighted UniFrac" = phyloseq::distance(ps_rel, "wunifrac"),
                "Aitchison"        = dist(clr))

  pmv <- data.frame()
  for (dn in names(dists)) {
    D <- dists[[dn]]
    mdd <- md[labels(D), , drop = FALSE]
    fml <- as.formula(paste("D ~ group * caries",
                            if (length(cov_use)) paste("+", paste(cov_use, collapse = " + ")) else ""))
    a <- tryCatch(adonis2(fml, data = mdd, permutations = PERM_N,
                          by = "terms"), error = function(e) NULL)
    if (is.null(a)) next
    for (trm in setdiff(rownames(a), c("Residual", "Total"))) {
      pmv <- rbind(pmv, data.frame(database = dbname, distance = dn,
                                   term = trm, R2 = a[trm, "R2"],
                                   F = a[trm, "F"], p = a[trm, "Pr(>F)"],
                                   stringsAsFactors = FALSE))
    }
  }
  write.csv(pmv, file.path(OUT, sprintf("permanova_twofactor_%s.csv", dbname)),
            row.names = FALSE)
  check_output(file.path(OUT, sprintf("permanova_twofactor_%s.csv", dbname)),
               sprintf("two-factor PERMANOVA (%s)", dbname))

  log_info("   variance explained (sequential):")
  for (dn in unique(pmv$distance)) {
    s <- pmv[pmv$distance == dn, ]
    log_info(sprintf("   %s", dn))
    for (i in seq_len(nrow(s)))
      log_info(sprintf("      %-16s R2 %.4f  p %.4f", s$term[i], s$R2[i], s$p[i]))
  }

  ## which exposure explains more?
  gg <- pmv[pmv$term == "group", ]
  cc <- pmv[pmv$term == "caries", ]
  if (nrow(gg) && nrow(cc)) {
    cmp <- merge(gg[, c("distance", "R2", "p")],
                 cc[, c("distance", "R2", "p")],
                 by = "distance", suffixes = c("_stunting", "_caries"))
    write.csv(cmp, file.path(OUT, sprintf("exposure_comparison_%s.csv", dbname)),
              row.names = FALSE)
    log_info("   stunting vs caries, variance explained:")
    for (i in seq_len(nrow(cmp)))
      log_info(sprintf("      %-18s stunting R2 %.4f (p %.4f) | caries R2 %.4f (p %.4f)",
                       cmp$distance[i], cmp$R2_stunting[i], cmp$p_stunting[i],
                       cmp$R2_caries[i], cmp$p_caries[i]))
  }

  ## ----------------------------------------------------------
  ## 3. Ordination by the four cells
  ## ----------------------------------------------------------
  o <- ordinate(ps_rel, method = "PCoA", distance = dists[["Aitchison"]])
  ev <- o$values$Relative_eig
  v <- as.data.frame(o$vectors[, 1:2]); names(v) <- c("Axis1", "Axis2")
  v <- merge(v, md, by = "row.names"); names(v)[1] <- "sample_id"

  p_cell <- ggplot(v, aes(Axis1, Axis2, colour = cell, fill = cell)) +
    stat_ellipse(geom = "polygon", alpha = 0.10, level = 0.80,
                 linewidth = 0.35) +
    geom_point(size = 2.3, alpha = 0.9) +
    scale_colour_manual(values = PAL$cell) +
    scale_fill_manual(values = PAL$cell) +
    labs(title = "Community structure by stunting and caries jointly",
         subtitle = sprintf("%s reference | Aitchison PCoA | 80%% ellipses",
                            toupper(dbname)),
         x = sprintf("PCoA 1 (%.1f%%)", 100 * ev[1]),
         y = sprintf("PCoA 2 (%.1f%%)", 100 * ev[2]),
         colour = NULL, fill = NULL) +
    theme_study(grid = "none") +
    guides(colour = guide_legend(nrow = 2))
  save_fig(p_cell, sprintf("08_01_pcoa_fourcell_%s", dbname), 7.5, 6.5,
           subdir = FIG)

  ## DMFT as a continuous overlay on the same ordination
  p_dm <- ggplot(v, aes(Axis1, Axis2)) +
    geom_point(aes(colour = dmft, shape = group), size = 2.6, alpha = 0.9) +
    scale_colour_viridis_c(option = "C", direction = -1) +
    labs(title = "Same ordination, coloured by caries burden",
         subtitle = sprintf("%s reference | DMFT as a continuous gradient",
                            toupper(dbname)),
         x = "PCoA 1", y = "PCoA 2", colour = "DMFT", shape = "Group") +
    theme_study(grid = "none")
  save_fig(p_dm, sprintf("08_02_pcoa_dmft_gradient_%s", dbname), 7, 6,
           subdir = FIG)

  ## ----------------------------------------------------------
  ## 4. Taxon-level: stunting vs caries effects side by side
  ## ----------------------------------------------------------
  log_info("--- taxon-level two-exposure model ---")
  status_write(sprintf("two-exposure taxon models (%s)", dbname))

  g <- prep_rank(ps, PRIMARY_RANK)
  if (is.null(g) || ntaxa(g) < 5) {
    log_warn("   too few features, taxon-level analysis skipped")
    next
  }
  log_info(sprintf("   %d %s-level features tested", ntaxa(g), PRIMARY_RANK))

  ## joint model: both exposures, mutually adjusted
  rr <- maas_fit(g, md, unique(c("group", "caries", cov_use)),
                 c("group,Non-stunted", "caries,Caries-free"),
                 sprintf("%s_joint", dbname))
  e_grp <- term_of(rr, "group",  "Stunted", "stunt")
  e_car <- term_of(rr, "caries", "Caries",  "caries")

  ## DMFT continuous, replacing binary caries
  rr2 <- maas_fit(g, md, unique(c("group", "dmft", cov_use)),
                  c("group,Non-stunted"), sprintf("%s_dmft", dbname))
  e_dmft <- term_of(rr2, "dmft", NULL, "dmft")
  e_grp2 <- term_of(rr2, "group", "Stunted", "stunt2")

  joint <- Reduce(function(a, b) merge(a, b, by = "taxon", all = TRUE),
                  Filter(Negate(is.null),
                         list(e_grp, e_car, e_dmft, e_grp2)))
  if (is.null(joint) || nrow(joint) == 0) {
    log_warn("   no model results returned")
    next
  }

  joint$sig_stunt  <- !is.na(joint$stunt_q)  & joint$stunt_q  < ALPHA
  joint$sig_caries <- !is.na(joint$caries_q) & joint$caries_q < ALPHA
  joint$sig_dmft   <- !is.na(joint$dmft_q)   & joint$dmft_q   < ALPHA

  joint$class <- ifelse(joint$sig_stunt & joint$sig_caries,
                   ifelse(sign(joint$stunt_coef) == sign(joint$caries_coef),
                          "Both, same direction", "Both, opposite direction"),
                 ifelse(joint$sig_stunt,  "Stunting only",
                 ifelse(joint$sig_caries, "Caries only", "Neither")))

  write.csv(joint, file.path(OUT, sprintf("taxa_two_exposure_%s.csv", dbname)),
            row.names = FALSE)
  check_output(file.path(OUT, sprintf("taxa_two_exposure_%s.csv", dbname)),
               sprintf("two-exposure taxon table (%s)", dbname))

  cl <- table(joint$class)
  log_info("   taxon classification:")
  for (k in names(cl)) log_info(sprintf("      %-26s %d", k, cl[[k]]))

  ## does DMFT continuous beat binary caries?
  n_bin <- sum(joint$sig_caries, na.rm = TRUE)
  n_con <- sum(joint$sig_dmft,   na.rm = TRUE)
  log_info(sprintf("   caries-associated taxa: %d with binary caries, %d with continuous DMFT",
                   n_bin, n_con))
  if (n_con > n_bin)
    log_info("   Continuous DMFT is the more sensitive parameterisation here.")

  ## how much does adjusting for caries change the stunting effect?
  if (!is.null(e_grp) && !is.null(e_grp2)) {
    rho <- suppressWarnings(cor(joint$stunt_coef, joint$stunt2_coef,
                                use = "complete.obs", method = "spearman"))
    log_info(sprintf("   stunting coefficients under binary vs continuous caries adjustment: rho %.3f",
                     rho))
  }

  ## ---- THE QUADRANT FIGURE: the paper's centrepiece ----
  jq <- joint[!is.na(joint$stunt_coef) & !is.na(joint$caries_coef), ]
  if (nrow(jq) > 3) {
    rho_e <- suppressWarnings(cor(jq$stunt_coef, jq$caries_coef,
                                  method = "spearman"))
    lab <- jq[jq$class != "Neither", ]
    lab <- head(lab[order(pmin(lab$stunt_q, lab$caries_q, na.rm = TRUE)), ],
                LABEL_N)

    cols <- c("Both, same direction"     = "#7048E8",
              "Both, opposite direction" = "#D00000",
              "Stunting only"            = "#E76F51",
              "Caries only"              = "#F4A261",
              "Neither"                  = "#CED4DA")

    p_q <- ggplot(jq, aes(caries_coef, stunt_coef, colour = class)) +
      annotate("rect", xmin = 0, xmax = Inf, ymin = 0, ymax = Inf,
               fill = "#7048E8", alpha = 0.04) +
      annotate("rect", xmin = -Inf, xmax = 0, ymin = -Inf, ymax = 0,
               fill = "#7048E8", alpha = 0.04) +
      geom_hline(yintercept = 0, colour = "#999999", linewidth = 0.35) +
      geom_vline(xintercept = 0, colour = "#999999", linewidth = 0.35) +
      geom_point(aes(size = class != "Neither"), alpha = 0.85) +
      scale_size_manual(values = c("FALSE" = 1.3, "TRUE" = 2.6),
                        guide = "none") +
      scale_colour_manual(values = cols) +
      { if (nrow(lab) > 0)
          geom_text(data = lab, aes(label = taxon), size = 2.4,
                    vjust = -0.9, show.legend = FALSE) } +
      labs(title = "Stunting and caries effects on the same taxa",
           subtitle = sprintf("%s / %s | mutually adjusted | Spearman rho = %.2f | shaded quadrants = concordant effects",
                              toupper(dbname), PRIMARY_RANK, rho_e),
           x = "Caries effect (coefficient)",
           y = "Stunting effect (coefficient)",
           colour = NULL,
           caption = "Upper-left and lower-right: taxa pushed in opposite directions by the two exposures.") +
      theme_study()
    save_fig(p_q, sprintf("08_03_quadrant_%s", dbname), 9.5, 7.5, subdir = FIG)
  }

  ## ---- taxa vs DMFT, continuous, top hits ----
  if (!is.null(e_dmft)) {
    top <- head(joint$taxon[order(joint$dmft_q)], 9)
    rel <- transform_sample_counts(g, function(x) x / sum(x))
    dfm <- psmelt(prune_taxa(top, rel))
    dfm$OTU <- factor(dfm$OTU, levels = top)
    p_dt <- ggplot(dfm, aes(dmft, Abundance + 1e-6)) +
      geom_point(aes(colour = group), size = 1.6, alpha = 0.75) +
      geom_smooth(method = "lm", formula = y ~ x, se = TRUE,
                  colour = "#2B2B2B", fill = "#DDDDDD", linewidth = 0.5) +
      facet_wrap(~ OTU, scales = "free_y", ncol = 3) +
      scale_y_log10() + scale_colour_study("group") +
      labs(title = "Taxa most strongly associated with caries burden",
           subtitle = sprintf("%s / %s | DMFT modelled continuously, adjusted for stunting, age and sex",
                              toupper(dbname), PRIMARY_RANK),
           x = "DMFT score", y = "Relative abundance", colour = "Group") +
      theme_study()
    save_fig(p_dt, sprintf("08_04_taxa_vs_dmft_%s", dbname), 9.5, 7.5,
             subdir = FIG)
  }

  ## ---- four-cell abundance panel for the discordant taxa ----
  disc <- joint$taxon[joint$class == "Both, opposite direction"]
  if (length(disc) > 0) {
    rel <- transform_sample_counts(g, function(x) x / sum(x))
    sel <- head(disc, 8)
    dfm <- psmelt(prune_taxa(sel, rel))
    dfm$cell <- factor(paste(dfm$group, dfm$caries, sep = " / "),
                       levels = names(PAL$cell))
    p_d <- ggplot(dfm, aes(cell, Abundance + 1e-6, fill = cell)) +
      geom_boxplot(outlier.shape = NA, alpha = 0.8, linewidth = 0.35,
                   colour = "#2B2B2B") +
      geom_jitter(width = 0.14, size = 1, alpha = 0.6, colour = "#3A3A3A") +
      facet_wrap(~ OTU, scales = "free_y", ncol = 4) +
      scale_y_log10() + scale_fill_manual(values = PAL$cell) +
      labs(title = "Taxa pushed in opposite directions by stunting and caries",
           subtitle = sprintf("%s / %s | these taxa are why caries cannot be treated as a nuisance variable",
                              toupper(dbname), PRIMARY_RANK),
           x = NULL, y = "Relative abundance", fill = NULL) +
      theme_study() +
      theme(axis.text.x = element_blank()) +
      guides(fill = guide_legend(nrow = 2))
    save_fig(p_d, sprintf("08_05_discordant_taxa_%s", dbname), 10, 7,
             subdir = FIG)
    log_info(sprintf("   %d discordant taxa: %s", length(disc),
                     paste(head(disc, 10), collapse = ", ")))
  } else {
    log_info("   no discordant taxa found. If stunting and caries move the")
    log_info("   community concordantly, that is itself the finding.")
  }

  ## ---- caries severity ordinal trend ----
  if ("caries_severity" %in% names(md)) {
    sev <- factor(md$caries_severity, levels = c("None", "Mild",
                                                 "Moderate-severe"),
                  ordered = TRUE)
    if (length(unique(na.omit(sev))) >= 3 && min(table(sev)) >= 4) {
      log_info("--- caries severity trend ---")
      D <- dists[["Aitchison"]]
      mdd <- md[labels(D), ]
      mdd$sev_num <- as.numeric(factor(mdd$caries_severity,
                          levels = c("None", "Mild", "Moderate-severe")))
      at <- tryCatch(adonis2(D ~ sev_num + group + age_months + sex,
                             data = mdd, permutations = PERM_N,
                             by = "margin"), error = function(e) NULL)
      if (!is.null(at)) {
        log_info(sprintf("   severity trend: R2 %.4f, p %.4f",
                         at["sev_num", "R2"], at["sev_num", "Pr(>F)"]))
        write.csv(as.data.frame(at),
                  file.path(OUT, sprintf("severity_trend_%s.csv", dbname)))
      }
    }
  }
}

log_info("")
log_info("KEY FIGURE: 08_03_quadrant_*.png")
log_info("  Taxa in the shaded quadrants respond to stunting and caries in")
log_info("  the same direction. Taxa off-diagonal respond in opposite")
log_info("  directions, and those are the ones that make caries adjustment")
log_info("  essential rather than optional in this cohort.")
log_info("")
log_info(sprintf("tables : %s", OUT))
log_info(sprintf("figures: %s", file.path(DIRS$fig, FIG)))
log_module_end()

## ============================================================
##  00_inventory.R
##  Phase 0 : raw data audit for the oral microbiome ASV pipeline
##
##  Checks : file parsing, R1/R2 pairing, cohort counts, lane
##           structure, read length, primer presence
##  Writes : 01_qc/inventory_report.txt
##           metadata/sample_manifest.csv
##
##  Run with:
##    Rscript "D:/oral data/scripts/00_inventory.R"
## ============================================================

suppressPackageStartupMessages({
  library(ShortRead)
  library(Biostrings)
})

## ---- paths ----
PROJ <- "D:/oral data"
RAW  <- file.path(PROJ, "00_raw")
QC   <- file.path(PROJ, "01_qc")
META <- file.path(PROJ, "metadata")

dir.create(QC,   showWarnings = FALSE, recursive = TRUE)
dir.create(META, showWarnings = FALSE, recursive = TRUE)

## ---- V3-V4 primers ----
FWD <- "CCTACGGGNGGCWGCAG"        # 341F
REV <- "GACTACHVGGGTATCTAATCC"    # 805R

## ---- capture output to file as well as console ----
report <- file.path(QC, "inventory_report.txt")
sink(report, split = TRUE)

cat("============================================================\n")
cat(" PHASE 0 INVENTORY\n")
cat(" ", format(Sys.time()), "\n")
cat("============================================================\n\n")

## ------------------------------------------------------------
## 1. Find and parse files
## ------------------------------------------------------------
fq <- list.files(RAW, pattern = "\\.(fq|fastq)\\.gz$", full.names = TRUE)
bn <- basename(fq)

if (length(fq) == 0) stop("No FASTQ files found in ", RAW)

cohort <- sub("^(KMU[A-Z]*)-.*$", "\\1", bn)
sampid <- sub("^(KMU[A-Z]*-[0-9]+).*$", "\\1", bn)
libid  <- ifelse(grepl("LFM[0-9]+", bn),
                 sub("^.*(LFM[0-9]+).*$", "\\1", bn), NA_character_)
lane   <- ifelse(grepl("_L[0-9]+_", bn),
                 sub("^.*_(L[0-9]+)_.*$", "\\1", bn), NA_character_)
readno <- sub("^.*_([12])\\.(fq|fastq)\\.gz$", "\\1", bn)

info <- data.frame(
  file    = bn,
  path    = fq,
  cohort  = cohort,
  sample  = sampid,
  library = libid,
  lane    = lane,
  read    = readno,
  size_mb = round(file.size(fq) / 1024^2, 1),
  stringsAsFactors = FALSE
)

cat("--- 1. FILE COUNTS ---\n")
cat(sprintf("  total FASTQ files : %d\n", nrow(info)))
cat(sprintf("  total size        : %.2f GB\n\n",
            sum(file.size(fq)) / 1024^3))

## ------------------------------------------------------------
## 2. Cohorts and lanes
## ------------------------------------------------------------
cat("--- 2. COHORTS (unique samples) ---\n")
coh_tab <- table(unique(info[, c("sample", "cohort")])$cohort)
for (k in names(coh_tab)) cat(sprintf("  %-8s %3d samples\n", k, coh_tab[[k]]))
cat(sprintf("\n  TOTAL    %3d samples\n\n", length(unique(info$sample))))

cat("--- 3. LANES ---\n")
print(table(info$lane, useNA = "ifany"))
n_lane_per_sample <- tapply(info$lane, info$sample,
                            function(x) length(unique(x)))
if (any(n_lane_per_sample > 1)) {
  cat("\n  ** WARNING: some samples span multiple lanes.\n")
  cat("     These must be concatenated (or error-modelled per run)\n")
  cat("     before DADA2. Affected samples:\n")
  print(names(n_lane_per_sample)[n_lane_per_sample > 1])
} else {
  cat("\n  OK: one lane per sample, no concatenation needed.\n")
}
cat("\n")

## ------------------------------------------------------------
## 3. R1 / R2 pairing
## ------------------------------------------------------------
cat("--- 4. PAIRING CHECK ---\n")
pair_tab <- table(info$sample, info$read)
bad <- rownames(pair_tab)[pair_tab[, "1"] != 1 | pair_tab[, "2"] != 1]
if (length(bad)) {
  cat("  ** WARNING: these samples do not have exactly one R1 and one R2:\n")
  print(pair_tab[bad, , drop = FALSE])
} else {
  cat("  OK: every sample has exactly one R1 and one R2.\n")
}
cat("\n")

## ------------------------------------------------------------
## 4. Read length and primer presence (subsample)
## ------------------------------------------------------------
cat("--- 5. READ LENGTH AND PRIMER PRESENCE ---\n")
cat("    (20,000 reads sampled per file, primers sought in first 40 bp)\n\n")

## pick up to 2 samples per cohort for the probe
probe_samples <- unlist(lapply(split(unique(info$sample),
                                     sub("-[0-9]+$", "", unique(info$sample))),
                               function(x) head(x, 2)))

check_primer <- function(path, primer, n = 20000) {
  fs <- FastqStreamer(path, n = n)
  on.exit(close(fs))
  rd <- yield(fs)
  if (length(rd) == 0) return(NULL)
  sq  <- sread(rd)
  len <- width(sq)
  win <- narrow(sq, start = 1, end = pmin(len, 40))
  hits <- vcountPattern(DNAString(primer), win,
                        fixed = FALSE, max.mismatch = 2)
  list(n_reads   = length(sq),
       len_min   = min(len),
       len_med   = median(len),
       len_max   = max(len),
       pct_hit   = 100 * mean(hits > 0))
}

res <- data.frame()
for (s in probe_samples) {
  r1 <- info$path[info$sample == s & info$read == "1"][1]
  r2 <- info$path[info$sample == s & info$read == "2"][1]
  if (is.na(r1) || is.na(r2)) next

  a <- tryCatch(check_primer(r1, FWD), error = function(e) NULL)
  b <- tryCatch(check_primer(r2, REV), error = function(e) NULL)
  if (is.null(a) || is.null(b)) next

  res <- rbind(res, data.frame(
    sample      = s,
    R1_len_med  = a$len_med,
    R1_FWD_pct  = round(a$pct_hit, 1),
    R2_len_med  = b$len_med,
    R2_REV_pct  = round(b$pct_hit, 1)
  ))
}
print(res, row.names = FALSE)

mean_fwd <- mean(res$R1_FWD_pct)
mean_rev <- mean(res$R2_REV_pct)
cat(sprintf("\n  mean 341F detection in R1 : %.1f %%\n", mean_fwd))
cat(sprintf("  mean 805R detection in R2 : %.1f %%\n\n", mean_rev))

cat("  INTERPRETATION\n")
if (mean_fwd > 70 && mean_rev > 70) {
  cat("  Primers are still on the reads. RUN 01_cutadapt.ps1 next.\n")
} else if (mean_fwd < 20 && mean_rev < 20) {
  cat("  Primers appear ALREADY REMOVED by the provider.\n")
  cat("  SKIP cutadapt and go straight to DADA2 filterAndTrim.\n")
} else {
  cat("  Ambiguous result. Do not proceed automatically.\n")
  cat("  Send this table back before running cutadapt.\n")
}
cat("\n")

## ------------------------------------------------------------
## 5. Write sample manifest
## ------------------------------------------------------------
manifest <- unique(info[, c("sample", "cohort", "library", "lane")])
manifest <- manifest[order(manifest$sample), ]
manifest$R1 <- info$file[match(paste0(manifest$sample, "_1"),
                               paste0(info$sample, "_", info$read))]
manifest$R2 <- info$file[match(paste0(manifest$sample, "_2"),
                               paste0(info$sample, "_", info$read))]
manifest$analysis_set <- ifelse(manifest$cohort %in% c("KMUN", "KMUS"),
                                "INCLUDE", "EXCLUDE_KMUOB")

out_csv <- file.path(META, "sample_manifest.csv")
write.csv(manifest, out_csv, row.names = FALSE)

cat("--- 6. MANIFEST ---\n")
cat(sprintf("  written : %s\n", out_csv))
cat(sprintf("  INCLUDE (KMUN + KMUS) : %d samples\n",
            sum(manifest$analysis_set == "INCLUDE")))
cat(sprintf("  EXCLUDE (KMUOB)       : %d samples\n\n",
            sum(manifest$analysis_set != "INCLUDE")))

cat("============================================================\n")
cat(" DONE. Report saved to:\n ", report, "\n")
cat("============================================================\n")

sink()

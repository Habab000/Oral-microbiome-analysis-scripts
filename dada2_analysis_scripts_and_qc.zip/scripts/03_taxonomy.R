## ============================================================
##  03_taxonomy.R   (CORRECTED)
##
##  Fix: reference files are now identified by INSPECTING THEIR
##  HEADERS, not by filename. assignTaxonomy needs a training
##  file with ">Level1;Level2;..." headers. assignSpecies needs
##  ">ID Genus species". Handing the wrong one to the wrong
##  function fails, or worse, produces nonsense.
## ============================================================

suppressPackageStartupMessages({ library(dada2) })

log_init("03_taxonomy")

seqtab <- ckpt_load("seqtab_final")
ids    <- ckpt_load("asv_ids")
seqs   <- colnames(seqtab)
log_info(sprintf("ASVs to classify: %d", length(seqs)))

## ------------------------------------------------------------
## 1. Classify every FASTA in 04_taxonomy by its header format
## ------------------------------------------------------------
log_step("Inspecting reference database files")

first_header <- function(path) {
  con <- gzfile(path, "rt")
  on.exit(close(con))
  for (i in 1:50) {
    ln <- readLines(con, n = 1, warn = FALSE)
    if (length(ln) == 0) break
    if (startsWith(ln, ">")) return(ln)
  }
  NA_character_
}

classify <- function(path) {
  h <- first_header(path)
  if (is.na(h)) return("unknown")
  ## training format: semicolon-delimited lineage
  if (grepl(";", h)) return("train")
  ## species format: ">ID Genus species"
  if (grepl("^>\\S+\\s+\\S+\\s+\\S+", h)) return("species")
  "unknown"
}

cands <- list.files(DIRS$tax, pattern = "\\.fa(sta)?\\.gz$",
                    full.names = TRUE, ignore.case = TRUE)
cands <- cands[!grepl("assignments", cands)]
if (length(cands) == 0)
  stop("No .fa.gz or .fasta.gz reference files in ", DIRS$tax)

ref <- data.frame(path = cands, file = basename(cands),
                  stringsAsFactors = FALSE)
ref$type <- vapply(ref$path, classify, character(1))
ref$db <- ifelse(grepl("silva", ref$file, ignore.case = TRUE), "silva",
          ifelse(grepl("homd",  ref$file, ignore.case = TRUE), "homd", "other"))

for (i in seq_len(nrow(ref))) {
  log_info(sprintf("   %-52s db=%-6s type=%s",
                   substr(ref$file[i], 1, 52), ref$db[i], ref$type[i]))
  log_info(sprintf("      header: %s",
                   substr(first_header(ref$path[i]), 1, 90)))
}

get_ref <- function(db, type) {
  hit <- ref$path[ref$db == db & ref$type == type]
  if (length(hit) == 0) return(NA_character_)
  hit[1]
}

silva_train <- get_ref("silva", "train")
silva_sp    <- get_ref("silva", "species")
homd_train  <- get_ref("homd",  "train")
homd_sp     <- get_ref("homd",  "species")

if (is.na(silva_train)) {
  log_err("No SILVA TRAINING file found (headers with semicolons).")
  log_err("  You need the 'toGenus_trainset' file, not only the")
  log_err("  'assignSpecies' file.")
  log_err("  https://zenodo.org/records/14169026")
  stop("SILVA training file missing")
}
log_ok(sprintf("SILVA train   : %s", basename(silva_train)))
if (is.na(silva_sp)) {
  log_warn("No SILVA species file. Species assignment will be skipped.")
} else {
  log_ok(sprintf("SILVA species : %s", basename(silva_sp)))
}

if (is.na(homd_train)) {
  log_warn("No HOMD TRAINING file found.")
  if (!is.na(homd_sp)) {
    log_warn(sprintf("  You have %s,", basename(homd_sp)))
    log_warn("  which is the assignSpecies file. assignTaxonomy needs")
    log_warn("  the 'dada2_taxonomy' file from the same Zenodo record.")
    log_warn("  https://doi.org/10.5281/zenodo.7380291")
  }
  log_warn("  Proceeding with SILVA only. Download the HOMD training")
  log_warn("  file later and rerun module 03 alone to add it.")
} else {
  log_ok(sprintf("HOMD train    : %s", basename(homd_train)))
}

## ------------------------------------------------------------
## 2. Assignment helper
## ------------------------------------------------------------
assign_db <- function(train, species, dbname) {
  log_step(sprintf("Assigning taxonomy: %s", toupper(dbname)))
  status_write(sprintf("assignTaxonomy against %s", dbname))

  tax <- cached(paste0("tax_", dbname), {
    t0 <- Sys.time()
    tt <- assignTaxonomy(seqs, train, minBoot = TAX_MINBOOT,
                         multithread = THREADS, verbose = FALSE)
    log_info(sprintf("assignTaxonomy took %.1f min",
                     as.numeric(difftime(Sys.time(), t0, units = "mins"))))
    if (ASSIGN_SPECIES && !is.na(species)) {
      status_write(sprintf("addSpecies against %s", dbname))
      t1 <- Sys.time()
      tt <- addSpecies(tt, species, verbose = FALSE)
      log_info(sprintf("addSpecies took %.1f min",
                       as.numeric(difftime(Sys.time(), t1, units = "mins"))))
    }
    tt
  })

  rownames(tax) <- ids$ids
  check_object(tax, sprintf("%s taxonomy matrix", dbname),
               expect_rows = length(seqs))

  cov <- data.frame(
    rank = colnames(tax),
    n_assigned = apply(tax, 2, function(x) sum(!is.na(x))),
    pct_assigned = round(100 * apply(tax, 2, function(x) mean(!is.na(x))), 1),
    n_unique = apply(tax, 2, function(x) length(unique(na.omit(x)))),
    stringsAsFactors = FALSE)

  log_info(sprintf("%s coverage:", toupper(dbname)))
  for (i in seq_len(nrow(cov)))
    log_info(sprintf("   %-9s %5d ASVs (%5.1f%%)  %4d unique taxa",
                     cov$rank[i], cov$n_assigned[i],
                     cov$pct_assigned[i], cov$n_unique[i]))

  tot <- colSums(seqtab)
  gen_col <- if ("Genus" %in% colnames(tax)) "Genus" else colnames(tax)[ncol(tax)]
  wgt <- 100 * sum(tot[!is.na(tax[, gen_col])]) / sum(tot)
  log_info(sprintf("   reads assigned to %s: %.1f%%", gen_col, wgt))
  if (wgt < 60)
    log_warn("   Under 60% of reads reach genus. Check that the database ",
             "matches the amplicon region.")

  p_tax <- file.path(DIRS$taxout, sprintf("tax_%s.csv", dbname))
  p_rds <- file.path(DIRS$taxout, sprintf("tax_%s.rds", dbname))
  p_cov <- file.path(DIRS$taxout, sprintf("coverage_%s.csv", dbname))

  write.csv(data.frame(ASV_ID = ids$ids, tax, sequence = seqs,
                       total_reads = as.numeric(tot),
                       stringsAsFactors = FALSE),
            p_tax, row.names = FALSE)
  saveRDS(tax, p_rds)
  write.csv(cov, p_cov, row.names = FALSE)

  check_output(p_tax, sprintf("%s taxonomy CSV", dbname))
  check_output(p_rds, sprintf("%s taxonomy RDS", dbname))
  check_output(p_cov, sprintf("%s coverage CSV", dbname))
  tax
}

## ------------------------------------------------------------
## 3. Run
## ------------------------------------------------------------
tax_silva <- assign_db(silva_train, silva_sp, "silva")

tax_homd <- NULL
if (!is.na(homd_train)) {
  tax_homd <- assign_db(homd_train, homd_sp, "homd")
}

## ------------------------------------------------------------
## 4. Concordance
## ------------------------------------------------------------
if (!is.null(tax_homd)) {
  log_step("SILVA vs HOMD concordance")

  common <- intersect(colnames(tax_silva), colnames(tax_homd))
  conc <- data.frame()
  for (r in common) {
    a <- tax_silva[, r]; b <- tax_homd[, r]
    both  <- !is.na(a) & !is.na(b)
    agree <- both & a == b
    conc <- rbind(conc, data.frame(
      rank = r, n_both_assigned = sum(both), n_agree = sum(agree),
      pct_agree = if (sum(both) > 0) round(100 * sum(agree) / sum(both), 1) else NA,
      silva_only = sum(!is.na(a) & is.na(b)),
      homd_only  = sum(is.na(a) & !is.na(b)),
      stringsAsFactors = FALSE))
  }
  p_conc <- file.path(DIRS$taxout, "concordance_silva_vs_homd.csv")
  write.csv(conc, p_conc, row.names = FALSE)
  check_output(p_conc, "SILVA vs HOMD concordance")

  log_info("agreement where both assigned:")
  for (i in seq_len(nrow(conc)))
    log_info(sprintf("   %-9s %5.1f%%  (silva-only %d, homd-only %d)",
                     conc$rank[i], conc$pct_agree[i],
                     conc$silva_only[i], conc$homd_only[i]))

  gi <- which(conc$rank == "Genus")
  if (length(gi) > 0 && !is.na(conc$pct_agree[gi]) && conc$pct_agree[gi] < 70) {
    log_warn("Genus agreement under 70%. Report both assignments and")
    log_warn("state clearly which one is primary in the methods.")
  }

  comb <- data.frame(ASV_ID = ids$ids, stringsAsFactors = FALSE)
  for (r in colnames(tax_silva)) comb[[paste0("SILVA_", r)]] <- tax_silva[, r]
  for (r in colnames(tax_homd))  comb[[paste0("HOMD_",  r)]] <- tax_homd[, r]
  comb$sequence <- seqs
  p_comb <- file.path(DIRS$taxout, "tax_combined.csv")
  write.csv(comb, p_comb, row.names = FALSE)
  check_output(p_comb, "combined dual-taxonomy table")
}

ckpt_save(list(silva = tax_silva, homd = tax_homd), "taxonomy")
log_module_end()

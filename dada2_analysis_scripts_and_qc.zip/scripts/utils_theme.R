## ============================================================
##  utils_theme.R
##  One visual identity for every figure in the paper: palette,
##  theme, and a save helper that writes PNG (300 dpi) and PDF
##  (vector, for the journal) side by side.
##
##  Sourced by every 06+ module. No package beyond ggplot2 is
##  required; viridis scales ship inside ggplot2.
## ============================================================

suppressPackageStartupMessages({ library(ggplot2) })

## ------------------------------------------------------------
##  Palettes. Colourblind-safe, checked for deuteranopia and
##  for legibility in greyscale print.
## ------------------------------------------------------------

PAL <- list(
  ## primary exposure
  group = c("Non-stunted" = "#2A9D8F",   # teal
            "Stunted"     = "#E76F51"),  # burnt coral

  ## the major confounder
  caries = c("Caries-free" = "#8ECAE6",
             "Caries"      = "#F4A261"),

  sex = c("Female" = "#9B5DE5",
          "Male"   = "#00BBF9"),

  anemia = c("Non-anemic" = "#80B918",
             "Anemic"     = "#D00000"),

  diet = c("Diverse/mixed"   = "#457B9D",
           "Staple-dominant" = "#E9C46A"),

  ## ordered, sequential
  age = c("36" = "#CDE7D4", "42" = "#5BA98B", "48" = "#1D6F5C"),

  severity = c("None"            = "#B7E4C7",
               "Mild"            = "#F4A261",
               "Moderate-severe" = "#BC4749"),

  lane = c("L1" = "#6C757D", "L2" = "#ADB5BD"),

  ## qualitative ramp for taxa stacked bars (15 + grey "Other")
  taxa = c("#4C6EF5", "#E8590C", "#0CA678", "#F03E3E", "#7048E8",
           "#F59F00", "#1098AD", "#D6336C", "#66A80F", "#845EF7",
           "#FD7E14", "#0B7285", "#C2255C", "#5C940D", "#364FC7",
           "Other" = "#CED4DA")
)

pal_for <- function(var) {
  if (!is.null(PAL[[var]])) return(PAL[[var]])
  NULL
}

## fill/colour scales that fall back gracefully
scale_fill_study  <- function(var, ...) {
  p <- pal_for(var)
  if (is.null(p)) scale_fill_viridis_d(option = "D", ...)
  else scale_fill_manual(values = p, ...)
}
scale_colour_study <- function(var, ...) {
  p <- pal_for(var)
  if (is.null(p)) scale_colour_viridis_d(option = "D", ...)
  else scale_colour_manual(values = p, ...)
}

## ------------------------------------------------------------
##  Theme
## ------------------------------------------------------------
theme_study <- function(base_size = 12, grid = "y") {
  th <- theme_minimal(base_size = base_size) +
    theme(
      text             = element_text(colour = "#1A1A1A"),
      plot.title       = element_text(face = "bold", size = base_size * 1.15,
                                      margin = margin(b = 4)),
      plot.subtitle    = element_text(colour = "#5A5A5A",
                                      size = base_size * 0.9,
                                      margin = margin(b = 10)),
      plot.caption     = element_text(colour = "#7A7A7A",
                                      size = base_size * 0.75, hjust = 0),
      axis.title       = element_text(size = base_size * 0.95),
      axis.text        = element_text(colour = "#3A3A3A"),
      axis.line        = element_line(colour = "#9A9A9A", linewidth = 0.3),
      panel.grid.minor = element_blank(),
      panel.grid.major = element_line(colour = "#E8E8E8", linewidth = 0.3),
      strip.text       = element_text(face = "bold", size = base_size * 0.9),
      strip.background = element_rect(fill = "#F2F2F2", colour = NA),
      legend.position  = "bottom",
      legend.title     = element_text(size = base_size * 0.85, face = "bold"),
      legend.key.size  = unit(0.9, "lines"),
      plot.margin      = margin(10, 12, 8, 10)
    )
  if (grid == "y") th <- th + theme(panel.grid.major.x = element_blank())
  if (grid == "x") th <- th + theme(panel.grid.major.y = element_blank())
  if (grid == "none") th <- th + theme(panel.grid.major = element_blank())
  th
}

theme_set(theme_study())

## ------------------------------------------------------------
##  Save helper: PNG for you, PDF for the journal
## ------------------------------------------------------------
save_fig <- function(plot, name, w = 8, h = 6, dpi = 300, subdir = NULL) {
  dir <- if (is.null(subdir)) DIRS$fig else file.path(DIRS$fig, subdir)
  dir.create(dir, showWarnings = FALSE, recursive = TRUE)
  png_p <- file.path(dir, paste0(name, ".png"))
  pdf_p <- file.path(dir, paste0(name, ".pdf"))
  ggsave(png_p, plot, width = w, height = h, dpi = dpi, bg = "white")
  ggsave(pdf_p, plot, width = w, height = h, device = cairo_pdf, bg = "white")
  if (exists("check_output")) {
    check_output(png_p, paste("figure:", name), fatal = FALSE)
  }
  invisible(png_p)
}

## significance stars, for annotating panels
star <- function(p) {
  if (is.na(p)) return("")
  if (p < 0.001) return("***")
  if (p < 0.01)  return("**")
  if (p < 0.05)  return("*")
  if (p < 0.10)  return(".")
  "ns"
}

fmt_p <- function(p) {
  if (is.na(p)) return("NA")
  if (p < 0.001) return("p < 0.001")
  sprintf("p = %.3f", p)
}

## ============================================================
##  05_phyloseq.R
##  Assemble the phyloseq objects, apply the analysis-set
##  subsetting (KMUOB dropped here, not earlier), filter
##  contaminants and rare ASVs, and validate everything.
##
##  Two objects are produced and kept separate throughout:
##    ps_silva  and  ps_homd
## ============================================================

suppressPackageStartupMessages({
  library(phyloseq); library(Biostrings)
})

log_init("05_phyloseq")

seqtab <- ckpt_load("seqtab_final")
ids    <- ckpt_load("asv_ids")
taxl   <- ckpt_load("taxonomy")
tree   <- ckpt_load("tree")
wide   <- ckpt_load("manifest_02")

## rename columns from sequences to ASV ids, keep sequences aside
stopifnot(identical(colnames(seqtab), ids$seqs))
colnames(seqtab) <- ids$ids
refseq_set <- DNAStringSet(ids$seqs); names(refseq_set) <- ids$ids

## ------------------------------------------------------------
## 1. Sample data
## ------------------------------------------------------------
log_step("Building sample data")

sd_p <- file.path(DIRS$meta, "sample_data_clean.csv")
if (!file.exists(sd_p))
  stop("sample_data_clean.csv missing. Run 00c_metadata_prep.R first.")
sd <- read.csv(sd_p, stringsAsFactors = FALSE)
log_info(sprintf("metadata rows: %d", nrow(sd)))

## attach lane, which is a processing variable not in the workbook
sd <- merge(sd, wide[, c("sample", "lane")],
            by.x = "sample_id", by.y = "sample", all.x = TRUE)

seq_samples <- rownames(seqtab)
in_both  <- intersect(sd$sample_id, seq_samples)
meta_only <- setdiff(sd$sample_id, seq_samples)
seq_only  <- setdiff(seq_samples, sd$sample_id)

log_info(sprintf("sequenced samples      : %d", length(seq_samples)))
log_info(sprintf("metadata samples       : %d", nrow(sd)))
log_info(sprintf("matched                : %d", length(in_both)))
if (length(meta_only)) {
  log_warn(sprintf("in metadata but not sequenced (%d): %s",
                   length(meta_only), paste(meta_only, collapse = ", ")))
}
if (length(seq_only)) {
  log_info(sprintf("sequenced but not in the analysis metadata (%d),",
                   length(seq_only)))
  log_info("   expected, since KMUOB is excluded from the metadata table")
}
if (length(in_both) == 0) stop("No sample IDs match. Check ID formatting.")

rownames(sd) <- sd$sample_id

## ------------------------------------------------------------
## 2. Assemble, per database
## ------------------------------------------------------------
build_ps <- function(tax, dbname) {
  log_step(sprintf("Assembling phyloseq object: %s", toupper(dbname)))

  common_asv <- intersect(colnames(seqtab), rownames(tax))
  ps <- phyloseq(
    otu_table(seqtab[in_both, common_asv, drop = FALSE], taxa_are_rows = FALSE),
    sample_data(sd[in_both, , drop = FALSE]),
    tax_table(as.matrix(tax[common_asv, , drop = FALSE])),
    phy_tree(tree),
    refseq(refseq_set[common_asv]))

  log_info(sprintf("raw object: %d samples, %d taxa",
                   nsamples(ps), ntaxa(ps)))
  ps
}

filter_ps <- function(ps, dbname) {
  log_info(sprintf("--- filtering (%s) ---", dbname))
  before_t <- ntaxa(ps); before_s <- nsamples(ps); before_r <- sum(otu_table(ps))

  ## kingdom
  kcol <- if ("Kingdom" %in% rank_names(ps)) "Kingdom" else
    if ("Domain" %in% rank_names(ps)) "Domain" else NA
  if (!is.na(kcol)) {
    kv <- as.character(tax_table(ps)[, kcol])
    keep <- !is.na(kv) & kv %in% KEEP_KINGDOM
    log_info(sprintf("  kingdom filter removes %d taxa", sum(!keep)))
    ps <- prune_taxa(keep, ps)
  }

  ## chloroplast and mitochondria, searched across all ranks
  tt <- as.data.frame(tax_table(ps), stringsAsFactors = FALSE)
  bad <- rep(FALSE, nrow(tt))
  for (r in colnames(tt))
    for (b in REMOVE_TAXA)
      bad <- bad | (!is.na(tt[[r]]) & grepl(b, tt[[r]], ignore.case = TRUE))
  log_info(sprintf("  chloroplast/mitochondria removes %d taxa", sum(bad)))
  ps <- prune_taxa(!bad, ps)

  ## prevalence and abundance
  ot <- as(otu_table(ps), "matrix")
  prev <- colSums(ot > 0); tot <- colSums(ot)
  keep <- prev >= MIN_PREVALENCE & tot >= MIN_TOTAL_COUNT
  log_info(sprintf("  prevalence >=%d and count >=%d removes %d taxa",
                   MIN_PREVALENCE, MIN_TOTAL_COUNT, sum(!keep)))
  ps <- prune_taxa(keep, ps)

  ## sample depth
  depths <- sample_sums(ps)
  low <- names(depths)[depths < MIN_READS_SAMPLE]
  if (length(low)) {
    log_warn(sprintf("  dropping %d samples below %d reads: %s",
                     length(low), MIN_READS_SAMPLE,
                     paste(low, collapse = ", ")))
    ps <- prune_samples(depths >= MIN_READS_SAMPLE, ps)
  }
  ps <- prune_taxa(taxa_sums(ps) > 0, ps)

  log_info(sprintf("  taxa    %d -> %d", before_t, ntaxa(ps)))
  log_info(sprintf("  samples %d -> %d", before_s, nsamples(ps)))
  log_info(sprintf("  reads retained: %.1f%%",
                   100 * sum(otu_table(ps)) / before_r))
  ps
}

validate_ps <- function(ps, dbname) {
  ok <- TRUE
  sd2 <- as(sample_data(ps), "data.frame")

  tb <- table(sd2$group)
  log_info(sprintf("  group sizes: %s",
                   paste(sprintf("%s=%d", names(tb), tb), collapse = "  ")))
  if (length(tb) < 2) { log_err("  only one group present"); ok <- FALSE }
  if (any(tb < 10)) { log_warn("  a group has fewer than 10 samples") }

  if (any(is.na(sd2$group))) { log_err("  NA in group"); ok <- FALSE }
  if (any(sample_sums(ps) == 0)) { log_err("  zero-depth sample"); ok <- FALSE }
  if (ntaxa(ps) < 50) { log_warn("  fewer than 50 taxa remain") }
  if (!identical(sort(taxa_names(ps)), sort(phy_tree(ps)$tip.label)))
    log_warn("  tree tips and taxa names differ; UniFrac will subset")

  d <- sample_sums(ps)
  log_info(sprintf("  depth: min %.0f  median %.0f  max %.0f  ratio %.1fx",
                   min(d), median(d), max(d), max(d) / min(d)))
  if (max(d) / min(d) > 20)
    log_warn("  depth varies more than 20-fold. Report this and rely on ",
             "normalisation-aware methods.")
  if (ok) log_ok(sprintf("  %s object validated", dbname))
  ok
}

results <- list()
for (dbname in names(taxl)) {
  tax <- taxl[[dbname]]
  if (is.null(tax)) { log_warn(sprintf("%s absent, skipped", dbname)); next }

  ps_all <- build_ps(tax, dbname)

  ## ---- the analysis subset happens HERE, not earlier ----
  sdd <- as(sample_data(ps_all), "data.frame")
  keep_s <- rownames(sdd)[sdd$cohort_code %in% ANALYSIS_COHORTS]
  ps_sub <- prune_samples(keep_s, ps_all)
  ps_sub <- prune_taxa(taxa_sums(ps_sub) > 0, ps_sub)
  log_info(sprintf("analysis subset (%s): %d samples, %d taxa",
                   paste(ANALYSIS_COHORTS, collapse = "+"),
                   nsamples(ps_sub), ntaxa(ps_sub)))

  ps_f <- filter_ps(ps_sub, dbname)
  validate_ps(ps_f, dbname)

  p_rds <- file.path(DIRS$ps, sprintf("ps_%s.rds", dbname))
  saveRDS(ps_f, p_rds)
  check_output(p_rds, sprintf("phyloseq object (%s)", dbname))

  ## flat exports, one set per database, clearly named
  write.csv(as(otu_table(ps_f), "matrix"),
            file.path(DIRS$export, sprintf("asv_table_%s.csv", dbname)))
  write.csv(as(tax_table(ps_f), "matrix"),
            file.path(DIRS$export, sprintf("taxonomy_%s.csv", dbname)))
  write.csv(as(sample_data(ps_f), "data.frame"),
            file.path(DIRS$export, sprintf("sample_data_%s.csv", dbname)))
  check_output(file.path(DIRS$export, sprintf("asv_table_%s.csv", dbname)),
               sprintf("ASV table CSV (%s)", dbname))

  ## relative abundance version, used by several downstream figures
  ps_rel <- transform_sample_counts(ps_f, function(x) x / sum(x))
  saveRDS(ps_rel, file.path(DIRS$ps, sprintf("ps_%s_relabund.rds", dbname)))

  results[[dbname]] <- ps_f
}

## ------------------------------------------------------------
## 3. Cross-database consistency
## ------------------------------------------------------------
if (length(results) == 2) {
  log_step("Cross-database consistency")
  a <- results[[1]]; b <- results[[2]]
  log_info(sprintf("  %s: %d samples, %d taxa", names(results)[1],
                   nsamples(a), ntaxa(a)))
  log_info(sprintf("  %s: %d samples, %d taxa", names(results)[2],
                   nsamples(b), ntaxa(b)))
  if (nsamples(a) != nsamples(b))
    log_warn("  sample counts differ between databases; check the filters")
  if (!setequal(sample_names(a), sample_names(b)))
    log_warn("  sample sets differ between databases")
  else log_ok("  identical sample sets across both databases")
}

ckpt_save(results, "phyloseq_objects")
log_info("")
log_info("Downstream modules should load:")
for (dbname in names(results))
  log_info(sprintf("   %s", file.path(DIRS$ps, sprintf("ps_%s.rds", dbname))))

log_module_end()

## ============================================================
##  07_differential_abundance.R
##
##  Two independent methods, ANCOM-BC2 and MaAsLin2, run on the
##  same features with the same covariates. A taxon is called
##  differentially abundant only when BOTH agree in significance
##  AND in direction. The method-comparison literature shows
##  these tools disagree substantially on the same data, so a
##  single-method result is not defensible.
##
##  Primary rank: Genus. Family, Phylum and ASV are run as
##  supporting analyses.
##
##  Outputs
##    06_analysis/differential_abundance/*.csv
##    07_figures/differential_abundance/*
## ============================================================

suppressPackageStartupMessages({
  library(phyloseq); library(ggplot2)
})

log_init("07_differential_abundance")
source(file.path(DIRS$scripts, "utils_theme.R"))

## ============================================================
##  CONFIG
## ============================================================
PRIMARY_DB   <- "homd"
PRIMARY_RANK <- "Genus"
RANKS        <- c("Phylum", "Family", "Genus")
DO_ASV       <- TRUE          # ASV level as supplementary
PRV_CUT      <- 0.10          # taxon must appear in >=10% of samples
ALPHA        <- 0.05
COVARS       <- c("age_months", "caries", "sex")
TOP_PLOT     <- 12            # taxa shown in the boxplot panel

OUT <- file.path(DIRS$ana, "differential_abundance")
FIG <- "differential_abundance"
dir.create(OUT, showWarnings = FALSE, recursive = TRUE)
dir.create(file.path(DIRS$fig, FIG), showWarnings = FALSE, recursive = TRUE)

HAS_ANCOM <- requireNamespace("ANCOMBC", quietly = TRUE)
HAS_MAAS  <- requireNamespace("Maaslin2", quietly = TRUE)
if (!HAS_ANCOM) log_err("ANCOMBC is not installed.")
if (!HAS_MAAS)  log_err("Maaslin2 is not installed.")
if (!HAS_ANCOM && !HAS_MAAS) stop("Neither DA method is available.")
if (!HAS_ANCOM || !HAS_MAAS)
  log_warn("Only one method available. Consensus reporting is disabled ",
           "and results should be treated as provisional.")

## ============================================================
##  Helpers
## ============================================================

meta_of <- function(ps) as(sample_data(ps), "data.frame")

usable_covars <- function(md, covars) {
  keep <- character()
  for (v in covars) {
    if (!v %in% names(md)) next
    x <- md[[v]]
    if (all(is.na(x)) || length(unique(na.omit(x))) < 2) next
    if (!is.numeric(x) && min(table(x)) < 3) next
    keep <- c(keep, v)
  }
  keep
}

## agglomerate and prevalence-filter
prep_rank <- function(ps, rank) {
  if (rank == "ASV") {
    g <- ps
  } else {
    if (!rank %in% rank_names(ps)) return(NULL)
    g <- tax_glom(ps, taxrank = rank, NArm = TRUE)
    tn <- as.character(tax_table(g)[, rank])
    ok <- !is.na(tn) & tn != ""
    g <- prune_taxa(ok, g)
    taxa_names(g) <- make.unique(as.character(tax_table(g)[, rank]))
  }
  ot <- as(otu_table(g), "matrix")
  if (taxa_are_rows(g)) ot <- t(ot)
  prev <- colSums(ot > 0) / nrow(ot)
  g <- prune_taxa(prev >= PRV_CUT, g)
  g
}

## ---------------- ANCOM-BC2 ----------------
run_ancombc <- function(g, md, cov_use, label) {
  if (!HAS_ANCOM) return(NULL)
  status_write(sprintf("ANCOM-BC2: %s", label))
  fml <- paste(c("group", cov_use), collapse = " + ")
  t0 <- Sys.time()
  r <- tryCatch(
    ANCOMBC::ancombc2(data = g, assay_name = "counts",
                      fix_formula = fml, group = "group",
                      p_adj_method = "BH", prv_cut = 0,
                      lib_cut = 0, struc_zero = TRUE, neg_lb = FALSE,
                      alpha = ALPHA, n_cl = THREADS, verbose = FALSE,
                      global = FALSE, pairwise = FALSE),
    error = function(e) { log_warn("ancombc2 failed: ", conditionMessage(e)); NULL })
  if (is.null(r)) return(NULL)
  log_info(sprintf("   ANCOM-BC2 %s: %.1f min", label,
                   as.numeric(difftime(Sys.time(), t0, units = "mins"))))

  res <- r$res
  lc <- grep("^lfc_groupStunted", names(res), value = TRUE)[1]
  qc <- grep("^q_groupStunted",   names(res), value = TRUE)[1]
  pc <- grep("^p_groupStunted",   names(res), value = TRUE)[1]
  sc <- grep("^se_groupStunted",  names(res), value = TRUE)[1]
  if (is.na(lc)) { log_warn("no groupStunted column in ancombc2 output"); return(NULL) }

  data.frame(taxon = res$taxon,
             anc_lfc = res[[lc]], anc_se = res[[sc]],
             anc_p = res[[pc]], anc_q = res[[qc]],
             stringsAsFactors = FALSE)
}

## ---------------- MaAsLin2 ----------------
run_maaslin <- function(g, md, cov_use, label, extra_fixed = NULL,
                        ref_group = "group,Non-stunted") {
  if (!HAS_MAAS) return(NULL)
  status_write(sprintf("MaAsLin2: %s", label))
  ot <- as(otu_table(g), "matrix")
  if (taxa_are_rows(g)) ot <- t(ot)
  md2 <- md[rownames(ot), , drop = FALSE]

  fixed <- unique(c("group", cov_use, extra_fixed))
  tmp <- file.path(tempdir(), paste0("maaslin_", gsub("\\W", "_", label)))

  t0 <- Sys.time()
  fit <- tryCatch(
    Maaslin2::Maaslin2(input_data = as.data.frame(ot),
                       input_metadata = md2,
                       output = tmp,
                       fixed_effects = fixed,
                       reference = ref_group,
                       normalization = "TSS", transform = "LOG",
                       analysis_method = "LM",
                       min_prevalence = 0, min_abundance = 0,
                       max_significance = 1,
                       correction = "BH",
                       plot_heatmap = FALSE, plot_scatter = FALSE,
                       standardize = FALSE),
    error = function(e) { log_warn("Maaslin2 failed: ", conditionMessage(e)); NULL })
  if (is.null(fit)) return(NULL)
  log_info(sprintf("   MaAsLin2 %s: %.1f min", label,
                   as.numeric(difftime(Sys.time(), t0, units = "mins"))))

  rr <- fit$results
  rr
}

maaslin_term <- function(rr, metadata_name, value_name = NULL) {
  if (is.null(rr)) return(NULL)
  s <- rr[rr$metadata == metadata_name, ]
  if (!is.null(value_name)) s <- s[s$value == value_name, ]
  if (nrow(s) == 0) return(NULL)
  data.frame(taxon = s$feature, mas_coef = s$coef, mas_se = s$stderr,
             mas_p = s$pval, mas_q = s$qval, stringsAsFactors = FALSE)
}

## ---------------- consensus ----------------
make_consensus <- function(anc, mas, label) {
  if (is.null(anc) && is.null(mas)) return(NULL)
  if (is.null(anc)) {
    m <- mas; m$anc_lfc <- NA; m$anc_q <- NA; m$anc_p <- NA; m$anc_se <- NA
  } else if (is.null(mas)) {
    m <- anc; m$mas_coef <- NA; m$mas_q <- NA; m$mas_p <- NA; m$mas_se <- NA
  } else {
    m <- merge(anc, mas, by = "taxon", all = TRUE)
  }

  m$sig_ancom   <- !is.na(m$anc_q) & m$anc_q < ALPHA
  m$sig_maaslin <- !is.na(m$mas_q) & m$mas_q < ALPHA
  m$same_direction <- !is.na(m$anc_lfc) & !is.na(m$mas_coef) &
                      sign(m$anc_lfc) == sign(m$mas_coef)

  m$consensus <- m$sig_ancom & m$sig_maaslin & m$same_direction
  m$status <- ifelse(m$consensus, "Consensus",
              ifelse(m$sig_ancom & m$sig_maaslin, "Both, opposite direction",
              ifelse(m$sig_ancom, "ANCOM-BC2 only",
              ifelse(m$sig_maaslin, "MaAsLin2 only", "Not significant"))))

  m$direction <- ifelse(is.na(m$anc_lfc),
                        ifelse(m$mas_coef > 0, "Higher in stunted",
                                               "Higher in non-stunted"),
                        ifelse(m$anc_lfc > 0, "Higher in stunted",
                                              "Higher in non-stunted"))
  m$rank_label <- label
  m[order(m$anc_q, m$mas_q), ]
}

log_consensus <- function(m, label) {
  n_a <- sum(m$sig_ancom, na.rm = TRUE)
  n_m <- sum(m$sig_maaslin, na.rm = TRUE)
  n_c <- sum(m$consensus, na.rm = TRUE)
  n_o <- sum(m$status == "Both, opposite direction", na.rm = TRUE)
  log_info(sprintf("   %-22s features %4d | ANCOM %3d | MaAsLin %3d | CONSENSUS %3d%s",
                   label, nrow(m), n_a, n_m, n_c,
                   if (n_o > 0) sprintf(" | conflicting %d", n_o) else ""))
  if (n_a + n_m > 0) {
    jac <- n_c / max(1, length(union(which(m$sig_ancom), which(m$sig_maaslin))))
    log_info(sprintf("     method agreement (Jaccard): %.2f", jac))
  }
  if (n_o > 0)
    log_warn(sprintf("     %d taxa significant in both but in OPPOSITE directions. ",
                     n_o), "Inspect before reporting.")
}

## ============================================================
##  Main
## ============================================================

all_res <- list()

for (dbname in c("silva", "homd")) {
  f <- file.path(DIRS$ps, sprintf("ps_%s.rds", dbname))
  if (!file.exists(f)) { log_warn(sprintf("%s missing, skipped", dbname)); next }

  log_step(sprintf("DIFFERENTIAL ABUNDANCE: %s", toupper(dbname)))

  ps <- readRDS(f)
  md <- meta_of(ps)
  md$sample_id <- NULL  # rownames carry the ID; a duplicate column breaks merges
  md$group  <- factor(md$group,  levels = c("Non-stunted", "Stunted"))
  md$caries <- factor(md$caries, levels = c("Caries-free", "Caries"))
  md$sex    <- factor(md$sex)
  sample_data(ps) <- sample_data(md)

  cov_use <- usable_covars(md, COVARS)
  log_info(sprintf("model: group + %s", paste(cov_use, collapse = " + ")))
  log_info(sprintf("prevalence cutoff: %.0f%% of samples", 100 * PRV_CUT))

  ranks <- RANKS
  if (DO_ASV) ranks <- c(ranks, "ASV")

  for (rk in ranks) {
    g <- prep_rank(ps, rk)
    if (is.null(g) || ntaxa(g) < 5) {
      log_warn(sprintf("   %s: too few features after filtering, skipped", rk))
      next
    }
    lab <- sprintf("%s / %s", dbname, rk)

    anc <- run_ancombc(g, md, cov_use, lab)
    rr  <- run_maaslin(g, md, cov_use, lab)
    mas <- maaslin_term(rr, "group", "Stunted")

    m <- make_consensus(anc, mas, rk)
    if (is.null(m)) next
    m$database <- dbname
    log_consensus(m, lab)

    write.csv(m, file.path(OUT, sprintf("da_%s_%s.csv", dbname, tolower(rk))),
              row.names = FALSE)
    all_res[[paste(dbname, rk)]] <- m

    ## ---- also capture the CARIES and DMFT coefficients from the
    ## ---- same MaAsLin2 fit; they cost nothing extra and feed module 08
    for (trm in list(list("caries", "Caries"), list("age_months", NULL))) {
      tt <- maaslin_term(rr, trm[[1]], trm[[2]])
      if (!is.null(tt)) {
        names(tt) <- sub("^mas_", "", names(tt))
        write.csv(tt, file.path(OUT, sprintf("covariate_%s_%s_%s.csv",
                  trm[[1]], dbname, tolower(rk))), row.names = FALSE)
      }
    }
  }

  ## ----------------------------------------------------------
  ##  Figures, primary rank only
  ## ----------------------------------------------------------
  key <- paste(dbname, PRIMARY_RANK)
  if (!is.null(all_res[[key]])) {
    m <- all_res[[key]]
    log_info(sprintf("--- figures for %s / %s ---", dbname, PRIMARY_RANK))

    ## volcano
    mv <- m[!is.na(m$anc_lfc) & !is.na(m$anc_q), ]
    if (nrow(mv) > 0) {
      mv$status <- factor(mv$status,
        levels = c("Consensus", "ANCOM-BC2 only", "MaAsLin2 only",
                   "Both, opposite direction", "Not significant"))
      cols <- c("Consensus" = "#D00000", "ANCOM-BC2 only" = "#F4A261",
                "MaAsLin2 only" = "#8ECAE6",
                "Both, opposite direction" = "#7048E8",
                "Not significant" = "#CED4DA")
      lbl <- mv[mv$consensus, ]
      lbl <- head(lbl[order(lbl$anc_q), ], 15)

      p_v <- ggplot(mv, aes(anc_lfc, -log10(pmax(anc_q, 1e-10)),
                            colour = status)) +
        geom_hline(yintercept = -log10(ALPHA), linetype = 2,
                   colour = "#888888", linewidth = 0.35) +
        geom_vline(xintercept = 0, colour = "#888888", linewidth = 0.35) +
        geom_point(aes(size = consensus), alpha = 0.8) +
        scale_size_manual(values = c("FALSE" = 1.4, "TRUE" = 2.6),
                          guide = "none") +
        scale_colour_manual(values = cols) +
        { if (nrow(lbl) > 0)
            geom_text(data = lbl, aes(label = taxon), size = 2.5,
                      vjust = -0.9, show.legend = FALSE) } +
        labs(title = sprintf("Differential abundance at %s level", PRIMARY_RANK),
             subtitle = sprintf("%s reference | adjusted for %s | positive = higher in stunted",
                                toupper(dbname), paste(cov_use, collapse = ", ")),
             x = "ANCOM-BC2 log fold change", y = expression(-log[10](q)),
             colour = NULL) +
        theme_study()
      save_fig(p_v, sprintf("07_01_volcano_%s_%s", dbname, tolower(PRIMARY_RANK)),
               9, 6.5, subdir = FIG)
    }

    ## method agreement scatter
    ms <- m[!is.na(m$anc_lfc) & !is.na(m$mas_coef), ]
    if (nrow(ms) > 3) {
      rho <- suppressWarnings(cor(ms$anc_lfc, ms$mas_coef,
                                  method = "spearman", use = "complete.obs"))
      p_ag <- ggplot(ms, aes(anc_lfc, mas_coef, colour = status)) +
        geom_hline(yintercept = 0, colour = "#BBBBBB", linewidth = 0.3) +
        geom_vline(xintercept = 0, colour = "#BBBBBB", linewidth = 0.3) +
        geom_point(alpha = 0.8, size = 1.8) +
        scale_colour_manual(values = c("Consensus" = "#D00000",
          "ANCOM-BC2 only" = "#F4A261", "MaAsLin2 only" = "#8ECAE6",
          "Both, opposite direction" = "#7048E8",
          "Not significant" = "#CED4DA")) +
        labs(title = "ANCOM-BC2 versus MaAsLin2 effect sizes",
             subtitle = sprintf("%s / %s | Spearman rho = %.2f | agreement in both magnitude and sign is what licenses a claim",
                                toupper(dbname), PRIMARY_RANK, rho),
             x = "ANCOM-BC2 log fold change", y = "MaAsLin2 coefficient",
             colour = NULL) +
        theme_study()
      save_fig(p_ag, sprintf("07_02_method_agreement_%s", dbname), 8.5, 6,
               subdir = FIG)
    }

    ## boxplots of the consensus taxa
    cons <- m$taxon[m$consensus]
    if (length(cons) > 0) {
      g <- prep_rank(ps, PRIMARY_RANK)
      rel <- transform_sample_counts(g, function(x) x / sum(x))
      keep <- head(m$taxon[m$consensus][order(m$anc_q[m$consensus])], TOP_PLOT)
      dfm <- psmelt(prune_taxa(keep, rel))
      dfm$OTU <- factor(dfm$OTU, levels = keep)

      p_box <- ggplot(dfm, aes(group, Abundance + 1e-6, fill = group)) +
        geom_boxplot(outlier.shape = NA, alpha = 0.75, linewidth = 0.35,
                     colour = "#2B2B2B") +
        geom_jitter(aes(colour = group), width = 0.14, size = 1.1,
                    alpha = 0.65, show.legend = FALSE) +
        facet_wrap(~ OTU, scales = "free_y", ncol = 4) +
        scale_y_log10(labels = function(x) format(x, scientific = TRUE)) +
        scale_fill_study("group") + scale_colour_study("group") +
        labs(title = "Consensus differentially abundant taxa",
             subtitle = sprintf("%s / %s | significant in BOTH methods, same direction | log scale",
                                toupper(dbname), PRIMARY_RANK),
             x = NULL, y = "Relative abundance", fill = "Group") +
        theme_study() + theme(axis.text.x = element_blank())
      save_fig(p_box, sprintf("07_03_consensus_boxplots_%s", dbname),
               10, 7.5, subdir = FIG)

      ## effect-size forest
      mf <- m[m$consensus, ]
      mf$taxon <- factor(mf$taxon, levels = mf$taxon[order(mf$anc_lfc)])
      p_f <- ggplot(mf, aes(anc_lfc, taxon, colour = direction)) +
        geom_vline(xintercept = 0, colour = "#999999", linewidth = 0.35) +
        geom_errorbarh(aes(xmin = anc_lfc - 1.96 * anc_se,
                           xmax = anc_lfc + 1.96 * anc_se),
                       height = 0, linewidth = 0.5) +
        geom_point(size = 2.4) +
        scale_colour_manual(values = c("Higher in stunted" = "#E76F51",
                                       "Higher in non-stunted" = "#2A9D8F")) +
        labs(title = "Consensus effect sizes with 95% intervals",
             subtitle = sprintf("%s / %s | ANCOM-BC2 log fold change",
                                toupper(dbname), PRIMARY_RANK),
             x = "Log fold change (stunted vs non-stunted)", y = NULL,
             colour = NULL) +
        theme_study(grid = "x")
      save_fig(p_f, sprintf("07_04_forest_%s", dbname), 8.5,
               max(4, 0.28 * nrow(mf) + 2.5), subdir = FIG)
    } else {
      log_warn(sprintf("   no consensus taxa at %s level for %s.",
                       PRIMARY_RANK, dbname))
      log_warn("   This is a real result, not a failure. Report the")
      log_warn("   single-method hits as exploratory and say so.")
    }
  }

  ## ----------------------------------------------------------
  ##  Differential PREVALENCE (presence/absence), genus level
  ## ----------------------------------------------------------
  log_info("--- differential prevalence ---")
  g <- prep_rank(ps, PRIMARY_RANK)
  ot <- as(otu_table(g), "matrix")
  if (taxa_are_rows(g)) ot <- t(ot)
  pres <- ot > 0
  mdp <- md[rownames(pres), ]
  prv <- data.frame()
  for (j in seq_len(ncol(pres))) {
    tb <- table(factor(pres[, j], levels = c(FALSE, TRUE)), mdp$group)
    ft <- tryCatch(fisher.test(tb)$p.value, error = function(e) NA_real_)
    prv <- rbind(prv, data.frame(
      taxon = colnames(pres)[j],
      prev_nonstunted = mean(pres[mdp$group == "Non-stunted", j]),
      prev_stunted    = mean(pres[mdp$group == "Stunted", j]),
      p = ft, stringsAsFactors = FALSE))
  }
  prv$q <- p.adjust(prv$p, "BH")
  prv <- prv[order(prv$q), ]
  write.csv(prv, file.path(OUT, sprintf("prevalence_%s.csv", dbname)),
            row.names = FALSE)
  log_info(sprintf("   taxa with prevalence difference q<0.05: %d",
                   sum(prv$q < ALPHA, na.rm = TRUE)))

  ## ----------------------------------------------------------
  ##  CARIES-FREE STRATIFIED RUN (exploratory)
  ## ----------------------------------------------------------
  log_info("--- caries-free stratified run ---")
  ps_cf <- prune_samples(md$caries == "Caries-free", ps)
  mdcf <- meta_of(ps_cf)
  tb <- table(mdcf$group)
  log_warn(sprintf("   caries-free subset: %s",
           paste(sprintf("%s=%d", names(tb), tb), collapse = "  ")))
  log_warn("   This stratum is small. Treat as EXPLORATORY only; it is")
  log_warn("   a check on whether the main signal survives, not a result")
  log_warn("   to claim in its own right.")

  if (min(tb) >= 5) {
    ps_cf <- prune_taxa(taxa_sums(ps_cf) > 0, ps_cf)
    gcf <- prep_rank(ps_cf, PRIMARY_RANK)
    if (!is.null(gcf) && ntaxa(gcf) >= 5) {
      cov_cf <- usable_covars(mdcf, setdiff(COVARS, "caries"))
      anc_cf <- run_ancombc(gcf, mdcf, cov_cf,
                            sprintf("%s / caries-free", dbname))
      rr_cf  <- run_maaslin(gcf, mdcf, cov_cf,
                            sprintf("%s_cariesfree", dbname))
      mas_cf <- maaslin_term(rr_cf, "group", "Stunted")
      mcf <- make_consensus(anc_cf, mas_cf, paste0(PRIMARY_RANK, "_cariesfree"))
      if (!is.null(mcf)) {
        mcf$database <- dbname
        log_consensus(mcf, sprintf("%s / caries-free", dbname))
        write.csv(mcf, file.path(OUT, sprintf("da_cariesfree_%s.csv", dbname)),
                  row.names = FALSE)

        ## does the main signal survive?
        main <- all_res[[key]]
        if (!is.null(main)) {
          mt <- main$taxon[main$consensus]
          if (length(mt) > 0) {
            surv <- intersect(mt, mcf$taxon[mcf$sig_ancom | mcf$sig_maaslin])
            log_info(sprintf("   %d of %d main-analysis consensus taxa remain",
                             length(surv), length(mt)))
            log_info(sprintf("   nominally significant in caries-free children"))
            if (length(surv) > 0)
              log_info("     ", paste(head(surv, 12), collapse = ", "))
          }
        }
      }
    }
  } else {
    log_warn("   a group has fewer than 5 caries-free children; run skipped")
  }
}

## ============================================================
##  Cross-database and cross-rank summary
## ============================================================
log_step("Summary across databases and ranks")

if (length(all_res) > 0) {
  comb <- do.call(rbind, lapply(names(all_res), function(k) {
    x <- all_res[[k]]
    x[, intersect(names(x), c("database", "rank_label", "taxon",
                              "anc_lfc", "anc_q", "mas_coef", "mas_q",
                              "status", "consensus", "direction"))]
  }))
  write.csv(comb, file.path(OUT, "da_all_combined.csv"), row.names = FALSE)
  check_output(file.path(OUT, "da_all_combined.csv"),
               "combined differential abundance table")

  smry <- aggregate(consensus ~ database + rank_label, comb, sum)
  names(smry)[3] <- "n_consensus"
  tot <- aggregate(taxon ~ database + rank_label, comb, length)
  names(tot)[3] <- "n_tested"
  smry <- merge(smry, tot)
  write.csv(smry, file.path(OUT, "da_summary.csv"), row.names = FALSE)
  log_info("consensus hits by database and rank:")
  print(smry, row.names = FALSE)

  ## taxa found in BOTH databases at the primary rank
  a <- all_res[[paste("silva", PRIMARY_RANK)]]
  b <- all_res[[paste("homd",  PRIMARY_RANK)]]
  if (!is.null(a) && !is.null(b)) {
    ta <- a$taxon[a$consensus]; tb2 <- b$taxon[b$consensus]
    both <- intersect(ta, tb2)
    log_info(sprintf("consensus taxa: SILVA %d, HOMD %d, in both %d",
                     length(ta), length(tb2), length(both)))
    if (length(both) > 0)
      log_info("   ", paste(both, collapse = ", "))
    writeLines(both, file.path(OUT, "consensus_taxa_both_databases.txt"))
  }
}

log_info("")
log_info(sprintf("tables : %s", OUT))
log_info(sprintf("figures: %s", file.path(DIRS$fig, FIG)))
log_module_end()

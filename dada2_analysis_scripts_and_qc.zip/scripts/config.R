## ============================================================
##  config.R   (CORRECTED)
##  Central configuration. The only file you normally edit.
## ============================================================

PROJ <- "D:/oral data"

## ---- compute -----------------------------------------------
THREADS  <- 6
RESUME   <- TRUE

## ---- primers (V3-V4) ---------------------------------------
FWD_PRIMER <- "CCTACGGGNGGCWGCAG"        # 341F, 17 nt
REV_PRIMER <- "GACTACHVGGGTATCTAATCC"    # 805R, 21 nt

PRIMER_HI <- 60
PRIMER_LO <- 15
PRIMER_MM <- 3

CUTADAPT_E   <- 0.20
CUTADAPT_MIN <- 100

## ---- DADA2 filtering ---------------------------------------
MAXEE   <- c(2, 2)
TRUNCQ  <- 2
MAXN    <- 0
RM_PHIX <- TRUE

## truncLen auto-selection
QUAL_TARGET   <- 30
QUAL_FALLBACK <- c(28, 25, 22, 20)
TRUNC_MIN_F   <- 200
TRUNC_MIN_R   <- 150
READ_LEN      <- 250          # raw read length, before primer removal

## CRITICAL: filterAndTrim DISCARDS any read shorter than truncLen.
## After primer removal the reads are shorter than READ_LEN, so
## truncLen is capped at this quantile of the observed length
## distribution. 0.02 keeps 98% of reads.
TRUNC_SAFETY_Q <- 0.02

## ---- overlap guard -----------------------------------------
AMPLICON_LEN <- 427    # V3-V4 length after primer removal
MIN_OVERLAP  <- 20

## ---- DADA2 denoising ---------------------------------------
POOL           <- "pseudo"
ERR_NBASES     <- 1e8
MERGE_MINOV    <- 12
CHIMERA_METHOD <- "consensus"

## ---- abort thresholds (safety nets) ------------------------
MIN_FILTER_PASS   <- 20   # percent; below this the run stops
MIN_CUTADAPT_KEEP <- 40   # percent; below this the run stops

## ---- taxonomy ----------------------------------------------
## Module 03 classifies each file by inspecting its FASTA header,
## so these patterns only need to find candidates, not identify
## which is which.
SILVA_FILE_PAT <- "silva.*\\.fa(sta)?\\.gz$"
HOMD_FILE_PAT  <- "(homd|HOMD).*\\.fa(sta)?\\.gz$"

TAX_MINBOOT    <- 80
ASSIGN_SPECIES <- TRUE

## ---- analysis set ------------------------------------------
PROCESS_COHORTS  <- c("KMUN", "KMUS", "KMUOB")
ANALYSIS_COHORTS <- c("KMUN", "KMUS")
GROUP_SOURCE     <- "prefix"

## ---- phyloseq filtering ------------------------------------
MIN_READS_SAMPLE <- 1000
MIN_PREVALENCE   <- 2
MIN_TOTAL_COUNT  <- 5
REMOVE_TAXA      <- c("Chloroplast", "Mitochondria")
KEEP_KINGDOM     <- c("Bacteria", "Archaea")

## ---- derived paths (do not edit) ---------------------------
DIRS <- list(
  raw    = file.path(PROJ, "00_raw"),
  qc     = file.path(PROJ, "01_qc"),
  trim   = file.path(PROJ, "02_trimmed"),
  dada   = file.path(PROJ, "03_dada2"),
  filt   = file.path(PROJ, "03_dada2", "filtered"),
  cache  = file.path(PROJ, "03_dada2", "cache"),
  tax    = file.path(PROJ, "04_taxonomy"),
  taxout = file.path(PROJ, "04_taxonomy", "assignments"),
  ps     = file.path(PROJ, "05_phyloseq"),
  ana    = file.path(PROJ, "06_analysis"),
  fig    = file.path(PROJ, "07_figures"),
  export = file.path(PROJ, "08_export"),
  meta   = file.path(PROJ, "metadata"),
  logs   = file.path(PROJ, "logs"),
  scripts= file.path(PROJ, "scripts")
)

for (d in DIRS) dir.create(d, showWarnings = FALSE, recursive = TRUE)

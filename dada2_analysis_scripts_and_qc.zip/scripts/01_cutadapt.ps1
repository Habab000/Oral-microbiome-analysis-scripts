# ============================================================
#  01_cutadapt.ps1
#  Phase 1 : primer removal (341F / 805R) for KMUN + KMUS only
#
#  PREREQUISITE: run 00_inventory.R first and confirm that the
#  primers are actually still present on the reads. If the
#  inventory says they are already removed, DO NOT run this.
#
#  Run with:
#    conda activate oralmb
#    powershell -File "D:\oral data\scripts\01_cutadapt.ps1"
# ============================================================

$ErrorActionPreference = "Stop"

# ---- paths ----
$PROJ = "D:\oral data"
$RAW  = Join-Path $PROJ "00_raw"
$TRIM = Join-Path $PROJ "02_trimmed"
$LOGS = Join-Path $TRIM "logs"

New-Item -ItemType Directory -Force -Path $TRIM | Out-Null
New-Item -ItemType Directory -Force -Path $LOGS | Out-Null

# ---- V3-V4 primers, anchored to the read start ----
$FWD = "^CCTACGGGNGGCWGCAG"       # 341F
$REV = "^GACTACHVGGGTATCTAATCC"   # 805R

# ---- settings ----
$ERR_RATE = 0.15   # allowed mismatch fraction in the primer
$MIN_LEN  = 100    # discard reads shorter than this after trimming
$THREADS  = 4      # drop to 1 if cutadapt errors on Windows multicore

# ---- sanity check ----
$cutadapt = Get-Command cutadapt -ErrorAction SilentlyContinue
if (-not $cutadapt) {
    Write-Host "cutadapt not found on PATH." -ForegroundColor Red
    Write-Host "Run 'conda activate oralmb' first." -ForegroundColor Yellow
    exit 1
}
Write-Host ("cutadapt : " + (& cutadapt --version)) -ForegroundColor Green

# ---- collect KMUN and KMUS R1 files ----
$r1files = Get-ChildItem $RAW -File |
    Where-Object { $_.Name -match '^(KMUN|KMUS)-\d+.*_1\.(fq|fastq)\.gz$' } |
    Sort-Object Name

Write-Host ("`nSamples to process : {0}" -f $r1files.Count) -ForegroundColor Cyan
if ($r1files.Count -eq 0) {
    Write-Host "No matching R1 files found. Check the naming pattern." -ForegroundColor Red
    exit 1
}

# ---- summary table ----
$summary = @()
$i = 0

foreach ($f in $r1files) {

    $i++
    $r1 = $f.FullName
    $r2 = $r1 -replace '_1\.(fq|fastq)\.gz$', '_2.$1.gz'

    if (-not (Test-Path $r2)) {
        Write-Host ("  [SKIP] no mate for " + $f.Name) -ForegroundColor Yellow
        continue
    }

    # sample id = first two hyphen-separated fields, e.g. KMUN-001
    $parts  = $f.Name -split '-'
    $sample = $parts[0] + "-" + $parts[1]

    $out1 = Join-Path $TRIM ($sample + "_R1_trimmed.fastq.gz")
    $out2 = Join-Path $TRIM ($sample + "_R2_trimmed.fastq.gz")
    $log  = Join-Path $LOGS ($sample + "_cutadapt.log")

    Write-Host ("  [{0,3}/{1}] {2}" -f $i, $r1files.Count, $sample)

    & cutadapt `
        -g $FWD `
        -G $REV `
        --discard-untrimmed `
        -e $ERR_RATE `
        -m $MIN_LEN `
        -j $THREADS `
        -o $out1 `
        -p $out2 `
        $r1 $r2 *> $log

    if ($LASTEXITCODE -ne 0) {
        Write-Host ("        FAILED, see " + $log) -ForegroundColor Red
        Write-Host "        If the error mentions cores or multiprocessing," -ForegroundColor Yellow
        Write-Host "        set THREADS = 1 at the top of this script." -ForegroundColor Yellow
        continue
    }

    # pull the pass rate out of the cutadapt log
    $txt  = Get-Content $log -Raw
    $inN  = if ($txt -match 'Total read pairs processed:\s+([\d,]+)') { $matches[1] } else { "?" }
    $outN = if ($txt -match 'Pairs written \(passing filters\):\s+([\d,]+)\s+\(([\d.]+)%\)') { $matches[1] } else { "?" }
    $pct  = if ($txt -match 'Pairs written \(passing filters\):\s+[\d,]+\s+\(([\d.]+)%\)') { [double]$matches[1] } else { $null }

    $summary += [pscustomobject]@{
        Sample   = $sample
        InPairs  = $inN
        OutPairs = $outN
        PctKept  = $pct
    }

    if ($pct -ne $null -and $pct -lt 70) {
        Write-Host ("        LOW retention: {0}%" -f $pct) -ForegroundColor Yellow
    }
}

# ---- report ----
Write-Host "`n=== CUTADAPT SUMMARY ===" -ForegroundColor Cyan
$summary | Format-Table -AutoSize

$csv = Join-Path $LOGS "cutadapt_summary.csv"
$summary | Export-Csv -Path $csv -NoTypeInformation
Write-Host ("`nSummary written to: " + $csv) -ForegroundColor Green

$kept = $summary | Where-Object { $_.PctKept -ne $null }
if ($kept.Count -gt 0) {
    $mean = ($kept | Measure-Object PctKept -Average).Average
    $low  = $kept | Where-Object { $_.PctKept -lt 70 }
    Write-Host ("Mean retention : {0:N1}%" -f $mean)
    if ($low.Count -gt 0) {
        Write-Host ("Samples below 70% retention: {0}" -f $low.Count) -ForegroundColor Yellow
        Write-Host "Review these before continuing to DADA2." -ForegroundColor Yellow
    }
}

Write-Host "`nNext: DADA2 quality profiles to choose truncLen.`n" -ForegroundColor Cyan

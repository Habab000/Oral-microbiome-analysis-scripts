## ============================================================
##  run_all.R   (CORRECTED - matches the new config.R)
##  Preflight checks first, then modules in order.
##  Start it from run_pipeline.ps1 so cutadapt is on PATH.
## ============================================================

SCRIPTS <- "D:/oral data/scripts"

source(file.path(SCRIPTS, "config.R"))
source(file.path(SCRIPTS, "utils_log.R"))

## ------------------------------------------------------------
##  Global error handler
## ------------------------------------------------------------
options(error = function() {
  msg <- geterrmessage()
  try(log_err("UNCAUGHT ERROR: ", trimws(msg)), silent = TRUE)
  cs <- try(sys.calls(), silent = TRUE)
  if (!inherits(cs, "try-error") && length(cs) > 0) {
    try(log_err("call stack:"), silent = TRUE)
    for (i in seq_along(cs)) {
      try(log_err(sprintf("   [%d] %s", i,
          substr(paste(deparse(cs[[i]]), collapse = " "), 1, 120))),
          silent = TRUE)
    }
  }
  try(status_write("FAILED, see log"), silent = TRUE)
  quit(status = 1, save = "no")
})

log_init("preflight")
log_step("Preflight checks")

fail <- character()

## ---- R packages --------------------------------------------
need <- c("dada2", "phyloseq", "DECIPHER", "phangorn", "Biostrings",
          "ShortRead", "ggplot2", "ape")
for (p in need) {
  if (requireNamespace(p, quietly = TRUE)) {
    log_ok(sprintf("%-12s %s", p, as.character(packageVersion(p))))
  } else {
    log_err(sprintf("%-12s MISSING", p))
    fail <- c(fail, p)
  }
}

## ---- raw data ----------------------------------------------
log_info("checking raw data directory: ", DIRS$raw)
if (!dir.exists(DIRS$raw)) {
  log_err("00_raw does not exist at ", DIRS$raw)
  fail <- c(fail, "raw_dir")
} else {
  nfq <- length(list.files(DIRS$raw, pattern = "\\.(fq|fastq)\\.gz$"))
  if (nfq == 0) {
    log_err("no FASTQ files in ", DIRS$raw)
    fail <- c(fail, "fastq")
  } else {
    log_ok(sprintf("FASTQ files found: %d", nfq))
  }
}

## ---- metadata ----------------------------------------------
sd_path <- file.path(DIRS$meta, "sample_data_clean.csv")
if (!file.exists(sd_path)) {
  log_err("sample_data_clean.csv missing. Run 00c_metadata_prep.R first.")
  log_err("  expected at: ", sd_path)
  fail <- c(fail, "metadata")
} else {
  sdf <- read.csv(sd_path, stringsAsFactors = FALSE)
  log_ok(sprintf("sample_data_clean.csv present (%d rows)", nrow(sdf)))
  if ("group" %in% names(sdf)) {
    tb <- table(sdf$group)
    for (g in names(tb)) log_info(sprintf("   group %-14s %d", g, tb[[g]]))
  }
  if ("cohort_code" %in% names(sdf)) {
    tc <- table(sdf$cohort_code)
    for (g in names(tc)) log_info(sprintf("   cohort %-13s %d", g, tc[[g]]))
  }
  if (nrow(sdf) < 54) {
    log_warn(sprintf("Only %d samples in the analysis metadata.", nrow(sdf)))
    log_warn("If you meant 27 vs 27, set KMUS013_RULE <- \"stunted\" in")
    log_warn("00c_metadata_prep.R and rerun it before starting.")
  }
}

## ---- reference databases, classified by HEADER --------------
log_info("inspecting reference databases in ", DIRS$tax)

first_header <- function(path) {
  con <- try(gzfile(path, "rt"), silent = TRUE)
  if (inherits(con, "try-error")) return(NA_character_)
  on.exit(close(con))
  for (i in 1:50) {
    ln <- readLines(con, n = 1, warn = FALSE)
    if (length(ln) == 0) break
    if (startsWith(ln, ">")) return(ln)
  }
  NA_character_
}

classify_ref <- function(path) {
  h <- first_header(path)
  if (is.na(h)) return("unknown")
  if (grepl(";", h)) return("train")
  if (grepl("^>\\S+\\s+\\S+\\s+\\S+", h)) return("species")
  "unknown"
}

cands <- list.files(DIRS$tax, pattern = "\\.fa(sta)?\\.gz$",
                    full.names = TRUE, ignore.case = TRUE)
cands <- cands[!grepl("assignments", cands)]

if (length(cands) == 0) {
  log_err("No reference FASTA files in ", DIRS$tax)
  log_err("  SILVA : https://zenodo.org/records/14169026")
  log_err("  HOMD  : https://doi.org/10.5281/zenodo.7380291")
  fail <- c(fail, "refdb")
} else {
  reftype <- vapply(cands, classify_ref, character(1))
  refdb <- ifelse(grepl("silva", basename(cands), ignore.case = TRUE), "silva",
           ifelse(grepl("homd",  basename(cands), ignore.case = TRUE), "homd",
                  "other"))
  for (i in seq_along(cands)) {
    log_info(sprintf("   %-50s db=%-6s type=%s",
                     substr(basename(cands[i]), 1, 50), refdb[i], reftype[i]))
  }

  has_silva_train <- any(refdb == "silva" & reftype == "train")
  has_silva_sp    <- any(refdb == "silva" & reftype == "species")
  has_homd_train  <- any(refdb == "homd"  & reftype == "train")
  has_homd_sp     <- any(refdb == "homd"  & reftype == "species")

  if (has_silva_train) {
    log_ok("SILVA training file present")
  } else {
    log_err("No SILVA TRAINING file (semicolon-delimited headers).")
    log_err("  You need the 'toGenus_trainset' file.")
    log_err("  https://zenodo.org/records/14169026")
    fail <- c(fail, "silva_train")
  }
  if (has_silva_sp) {
    log_ok("SILVA species file present")
  } else {
    log_warn("No SILVA species file. Species assignment will be skipped.")
  }

  if (has_homd_train) {
    log_ok("HOMD training file present")
  } else {
    log_warn("No HOMD TRAINING file found.")
    if (has_homd_sp) {
      log_warn("  You have the HOMD assignSpecies file, which cannot be")
      log_warn("  used by assignTaxonomy. Download the 'dada2_taxonomy'")
      log_warn("  file from the same Zenodo record.")
    }
    log_warn("  https://doi.org/10.5281/zenodo.7380291")
    log_warn("  The run will proceed with SILVA only. Rerun module 03")
    log_warn("  alone later to add HOMD.")
  }
}

## ---- cutadapt ----------------------------------------------
if (nzchar(Sys.which("cutadapt"))) {
  log_ok("cutadapt on PATH")
} else {
  log_warn("cutadapt not on PATH. If primers are present, module 01")
  log_warn("  will stop. Launch via run_pipeline.ps1.")
}

## ---- disk space --------------------------------------------
free_gb <- tryCatch({
  x <- system2("powershell", c("-NoProfile", "-Command",
       "(Get-PSDrive D).Free/1GB"), stdout = TRUE, stderr = FALSE)
  suppressWarnings(as.numeric(x[1]))
}, error = function(e) NA_real_)

if (!is.na(free_gb)) {
  log_info(sprintf("free space on D: %.1f GB", free_gb))
  if (free_gb < 40) log_warn("Under 40 GB free. Caches need room.")
} else {
  log_info("could not read free disk space, continuing")
}

## ---- verdict -----------------------------------------------
if (length(fail) > 0) {
  log_err("")
  log_err("PREFLIGHT FAILED: ", paste(unique(fail), collapse = ", "))
  log_err("Nothing has been run. Fix the above and start again.")
  status_write("PREFLIGHT FAILED")
  quit(status = 1, save = "no")
}

log_ok("preflight passed")
log_module_end()

## ------------------------------------------------------------
##  MODULES
## ------------------------------------------------------------
MODULES <- c(
  "01_qc_primers.R",
  "02_dada2.R",
  "03_taxonomy.R",
  "04_tree.R",
  "05_phyloseq.R"
)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 0) {
  MODULES <- MODULES[substr(MODULES, 1, 2) %in% args]
  log_info("restricted run: ", paste(MODULES, collapse = ", "))
  if (length(MODULES) == 0) {
    log_err("no modules matched: ", paste(args, collapse = ", "))
    quit(status = 1, save = "no")
  }
}

t_start   <- Sys.time()
done      <- character()
failed_at <- NA_character_

for (m in MODULES) {
  path <- file.path(SCRIPTS, m)
  if (!file.exists(path)) {
    log_err("module not found: ", path)
    failed_at <- m
    break
  }
  ok <- tryCatch({
    source(path, local = new.env())
    TRUE
  }, error = function(e) {
    log_err("MODULE FAILED: ", m)
    log_err("  ", conditionMessage(e))
    log_err("")
    log_err("Nothing after this point has run. Cached work from earlier")
    log_err("modules is kept, so fixing the cause and rerunning will")
    log_err("resume rather than start over.")
    status_write(sprintf("FAILED in %s", m))
    FALSE
  })
  if (!ok) {
    failed_at <- m
    break
  }
  done <- c(done, m)
}

## ------------------------------------------------------------
##  SUMMARY
## ------------------------------------------------------------
mins <- as.numeric(difftime(Sys.time(), t_start, units = "mins"))
log_msg("", "")
log_msg("", strrep("=", 62))
if (is.na(failed_at)) {
  log_msg("", " PIPELINE COMPLETE")
} else {
  log_msg("", sprintf(" PIPELINE STOPPED IN %s", failed_at))
}
log_msg("", sprintf(" modules run : %s",
        if (length(done) > 0) paste(done, collapse = ", ") else "none"))
log_msg("", sprintf(" total time  : %.1f min (%.1f h)", mins, mins / 60))
log_msg("", strrep("=", 62))

chk <- file.path(DIRS$logs, "outputs_check.csv")
if (file.exists(chk)) {
  cc <- read.csv(chk, stringsAsFactors = FALSE)
  nfail <- sum(cc$status != "OK")
  log_msg("", sprintf(" outputs verified : %d", sum(cc$status == "OK")))
  if (nfail > 0) {
    log_msg("", sprintf(" outputs FAILED   : %d", nfail))
    bad <- cc[cc$status != "OK", c("module", "description")]
    for (i in seq_len(nrow(bad))) {
      log_msg("", sprintf("   %s : %s", bad$module[i], bad$description[i]))
    }
  }
}

log_msg("", sprintf(" full log    : %s", .LOGENV$file))
log_msg("", sprintf(" live status : %s", file.path(DIRS$logs, "STATUS.txt")))

if (is.na(failed_at)) {
  status_write("PIPELINE COMPLETE")
} else {
  quit(status = 1, save = "no")
}

# Oral Microbiome ASV Pipeline

Stunted vs non-stunted salivary microbiome, KMUN + KMUS, 16S rRNA V3-V4.
All 84 samples are denoised; KMUOB is dropped at module 05.

---

## 1. One-time setup

Put these eight files in `D:\oral data\scripts\`:

```
config.R              all parameters, the only file you edit
utils_log.R           logging, progress, validation, checkpoints
01_qc_primers.R       primer detection, auto-branch, cutadapt
02_dada2.R            truncLen, filtering, per-lane errors, denoising
03_taxonomy.R         SILVA + HOMD, tracked separately
04_tree.R             neighbour-joining tree
05_phyloseq.R         assembly, subsetting, filtering, validation
run_all.R             master runner with preflight
run_pipeline.ps1      launcher
```

Download the reference databases into `D:\oral data\04_taxonomy\`:

- SILVA 138.2, DADA2-formatted: https://zenodo.org/records/14169026
  (take the `toGenus` trainset and the `assignSpecies` file)
- HOMD, DADA2-formatted: https://doi.org/10.5281/zenodo.7380291

Do not unzip them. DADA2 reads `.fa.gz` directly.

Set `KMUS013_RULE <- "stunted"` in `00c_metadata_prep.R` and run it, so
that `metadata/sample_data_clean.csv` exists with 27 vs 27.

---

## 2. Run

```powershell
powershell -ExecutionPolicy Bypass -File "D:\oral data\scripts\run_pipeline.ps1"
```

Watch it from a **second** PowerShell window:

```powershell
Get-Content "D:\oral data\logs\STATUS.txt" -Wait
```

That refreshes continuously and shows the module, the step, a progress
bar, the current sample, how many remain, and an ETA.

Rerun only some modules:

```powershell
... run_pipeline.ps1 -Modules 03,04,05
```

---

## 3. What gets written

```
logs/
  pipeline_<timestamp>.log    full append-only history
  STATUS.txt                  live state, overwritten continuously
  outputs_check.csv           every expected output, with OK or FAIL

01_qc/    primer_detection.csv, filter_stats.csv, read_tracking.csv
02_trimmed/  trimmed FASTQ + per-sample cutadapt logs
03_dada2/    cache/ (checkpoints), filtered/, seqtab_final.rds
04_taxonomy/assignments/
             tax_silva.csv / .rds / coverage_silva.csv
             tax_homd.csv  / .rds / coverage_homd.csv
             concordance_silva_vs_homd.csv
             tax_combined.csv
05_phyloseq/ ps_silva.rds, ps_homd.rds, + relative-abundance versions
07_figures/  quality profiles, error models
08_export/   ASVs.fasta, ASVs_tree.nwk, asv_table_<db>.csv, ...
```

The two taxonomies never share a file. Every SILVA output carries
`_silva`, every HOMD output carries `_homd`, and `concordance` reports
where they disagree.

---

## 4. Resuming

`RESUME <- TRUE` in `config.R` means every expensive step is cached in
`03_dada2/cache/`. If the run dies at hour six, fixing the cause and
starting again picks up where it stopped.

To force a step to rerun, delete its cache file. To start clean:

```powershell
... run_pipeline.ps1 -Fresh
```

---

## 5. Contingency plans already built in

| Situation | What the pipeline does |
|---|---|
| Primers present | Runs cutadapt with `--discard-untrimmed` |
| Primers already removed | Skips cutadapt, uses raw files |
| **Primer signal ambiguous** | Runs cutadapt in lenient mode: strips primers where found, keeps reads without one. Safe either way. |
| Mixed read orientation | Detected and logged loudly before it corrupts the ASV table |
| Two sequencing lanes | Error models learned per lane, tables merged after |
| Lane confounded with group | Tested and reported as a limitation |
| `truncLen` would break merging | Quality cutoff relaxed stepwise, then untruncated; aborts with an explanation rather than producing a bad table |
| Merge rate under 50% | Warns and tells you exactly which cache to delete |
| Cutadapt retention under 40% | Stops rather than continue on bad data |
| A sample yields no reads | Dropped with a named warning, run continues |
| HOMD not downloaded | Proceeds SILVA-only; rerun module 03 later to add it |
| Reference DB missing | Caught in preflight, before any compute is spent |
| Any module errors | Run stops, cause logged, earlier work preserved |

---

## 6. Runtime, roughly, on a 5600X with 6 cores

| Module | Expected |
|---|---|
| 01 primers + cutadapt | 30 to 60 min |
| 02 DADA2 (84 samples, pseudo-pooled) | 4 to 8 h |
| 03 taxonomy, both databases | 1 to 3 h |
| 04 NJ tree | 1 to 4 h, scales with ASV count |
| 05 phyloseq | under 5 min |

Total roughly 8 to 15 hours. Start it in the evening.

If module 02 is taking too long, set `POOL <- FALSE` in `config.R`.
That roughly halves the time at some cost in sensitivity for rare ASVs.

---

## 7. Known limits

- `filterAndTrim` runs single-threaded. Its forked parallelism does not
  exist on Windows, and forcing it would error or silently fall back.
- PICRUSt2 is not included. It has no Windows build. `08_export/ASVs.fasta`
  and `asv_table_silva.csv` are written in the formats it expects, so it
  can be run later under WSL or on a Linux machine.
- SpiecEasi needs Rtools to compile. Install Rtools before the network
  analysis module.
- The analysis modules (diversity, differential abundance, networks, ML)
  are separate and come after this stage.
